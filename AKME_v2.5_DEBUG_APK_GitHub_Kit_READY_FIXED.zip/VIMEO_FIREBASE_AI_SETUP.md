# AKME Firebase + Vimeo + Gemini integration

- Vimeo upload ticket is created by the authenticated Firebase callable function `createVimeoUpload`.
- The Vimeo token is stored as Firebase Functions secret `VIMEO_ACCESS_TOKEN`, not in the mobile app.
- The app uploads video bytes using Vimeo's resumable TUS endpoint, then saves video metadata in Firestore `posts`.
- Gemini captions use Firebase AI Logic (`firebase_ai`) and model `gemini-3.8-flash`.
- Enable the Gemini Developer API provider in Firebase AI Logic before testing.
- Android Firebase initialization uses `android/app/google-services.json`; package ID is `com.akme`.
- Before production, enable App Check, add upload quotas/moderation, deploy the rules/functions, and test uploads.
