# AKME — Firebase backend starter

This package adds a Firebase backend layer to the AKME Flutter starter.

## Included
- Firebase email/password registration and sign-in wired to the login screen.
- Firestore user profiles and post records.
- Firebase Storage upload method for image/video posts.
- Firestore like/unlike transactions and comment methods.
- Follow/follower records, profile update method, and leaderboard stream.
- Firestore and Storage security rules in `backend/`.

## Important: cloud setup is still required
This ZIP contains the app-side integration and security rules. It does **not** create a Firebase project or deploy a live backend automatically. You must connect it to your own Firebase project (never share your private service-account key or passwords).

1. Create/open a Firebase project at https://console.firebase.google.com/ .
2. Add an Android app using the exact `applicationId` from `android/app/build.gradle` (create Android platform files first if absent).
3. Enable **Authentication → Email/Password**.
4. Create a **Cloud Firestore** database and enable **Storage**.
5. Install Flutter and Firebase CLI / FlutterFire CLI, then from this project folder run:

   ```bash
   flutter create --platforms=android .
   flutter pub get
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```

   Select your Firebase project and Android app. This generates `lib/firebase_options.dart` used by `main.dart`.
6. Deploy the rules in `backend/firestore.rules` and `backend/storage.rules` using Firebase Console → Firestore/Storage → Rules (or Firebase CLI).
7. Run `flutter run`. Build a release APK with `flutter build apk --release` after testing.

## Backend service API
Use `AkmeBackend.instance` from `lib/services/akme_backend.dart`:
- `signUp`, `signIn`, `signOut`, `authChanges`
- `feed`, `uploadPost`
- `toggleLike`, `isLiked`
- `comments`, `addComment`
- `follow`, `leaderboard`, `updateProfile`

## Cloud Functions and deployment

The `functions/` folder contains Node.js 20 Cloud Functions. They maintain post like/comment counters and creator points on the trusted server. The Flutter client only creates/deletes like and comment documents; it cannot write counter fields.

### Deploy to your Firebase project

1. Install Node.js 20 and Firebase CLI.
2. In this project folder run `firebase login` using your own Google account.
3. Copy `.firebaserc.example` to `.firebaserc`, then replace `YOUR_FIREBASE_PROJECT_ID` with your Firebase project ID.
4. Run `cd functions && npm install && cd ..`.
5. Run `firebase deploy --only firestore:rules,storage,functions`.
6. Check Firebase Console billing requirements. Cloud Functions deployment may require the Blaze plan; review costs and set budget alerts before enabling billing.
7. Enable Email/Password in Authentication, create Firestore and Storage, then run `flutterfire configure` to generate `lib/firebase_options.dart`.

This ZIP cannot deploy into a private Firebase account by itself. Deployment requires you to sign in and authorize Firebase CLI. Never share your password, OTP, or service-account private key.

## Current integration status
The login and sign-up screen call Firebase Authentication. The backend service methods for feed, media uploads, likes, comments, follows, leaderboard and profile are included for the next UI wiring step; the current sample feed and create sheet are still demonstration UI and do not yet call those methods. Messaging/DMs are not implemented. Do not publish this starter as a complete social network until those screens are connected, tested, and moderation/reporting controls are added.


## Security rules notes
The `backend/firestore.rules` and `backend/storage.rules` files are included and tightened for authenticated users, owner-only profile edits, post ownership, and media type/size limits. Deploy them in Firebase Console → Firestore Database → Rules and Storage → Rules. These files are not deployed to your Firebase project by downloading this ZIP.

Important: this starter currently writes like/comment documents from the app, but post counter updates are intentionally restricted to post owners. To keep counters accurate, move counter updates to a trusted Cloud Function before enabling public production use. Never make counter fields client-writable just to bypass a permission error.


## Legal screens added in this package
- Profile → Legal & Documents opens five in-app draft policy screens.
- Profile → Request Account Deletion explains that automated deletion is not implemented yet.
- Profile → Report a Problem is currently informational only; reporting workflow is not implemented.

Before public release, confirm the legal operator details (KEDIR JAMLE KLIIL; tradingkedir@gmail.com; akomasaneakomasanu@gmail.com), add the applicable jurisdiction, reconcile the Privacy Policy with actual Firebase data collection and enabled services, implement report/block/moderation and account deletion workflows, and obtain legal review. These screens do not make those backend functions operational.


## Legal, reporting and account deletion additions
- Sign-up requires an explicit Terms of Service and Privacy Policy acceptance; acceptance version/time are stored in the user profile document.
- Profile > Legal & Documents displays the five policy pages. These are drafts: verify operator/contact details (KEDIR JAMLE KLIIL; tradingkedir@gmail.com; akomasaneakomasanu@gmail.com), add the applicable jurisdiction, and verify actual data practices before public release.
- Profile > Report a Problem submits a report to Firestore `reports`. It does not provide a moderation dashboard; the operator must securely monitor and review reports.
- Profile > Request Account Deletion submits a request to Firestore `deletionRequests`. It does not itself delete Authentication users, posts, Storage files, backups or other records. A secure operator-side deletion process is still required.
- Deploy the updated `backend/firestore.rules` to the Firebase project before testing report/deletion requests.


## AKME Smart Ranking Engine (ASRE) v1
The For You feed ranks up to 100 recent posts using bounded freshness, public engagement counts, explicit liked-caption topic tokens, followed creators, and a small new-creator exploration boost. It limits repeated creators in adjacent feed positions. Users can select Following or For You and mark a post Not interested; hidden post IDs are stored under `users/{uid}/feedSignals`. It deliberately does not optimize for watch-time loops or use sensitive personal attributes. Ranking runs in the Flutter client for this MVP; a production-scale version should move candidate retrieval/ranking to a trusted backend and add pagination, abuse/spam filtering, safety review and offline evaluation. Deploy the updated Firestore rules before testing this feature.


## ASRE v1.1 update
- Negative topic feedback now lowers similar recommendations as well as hiding the selected post.
- Explicitly ineligible/private/removed posts are filtered out.
- Engagement Cloud Functions use event-ID deduplication to avoid double-counting on retries.
- Android launcher vector icon and release signing Gradle wiring are included.
- Copy the private signing files to `android/key.properties` and `android/app/akme-release-key.jks` before release build.

## ASRE v1.3 notes

The ranking engine now exposes a pure `scorePost` method for unit testing,
uses exact token matching for interests, applies a conservative fallback age
when `createdAt` is missing, and uses deterministic tie-breaking. Posts marked
`removed`, `blocked`, `rejected`, or `underReview` are excluded from
recommendations. Run `flutter test` in a Flutter-enabled environment before
shipping.


## ASRE v1.4 — Saved-post preference
The For You ranking now includes an explicit bookmark signal. Posts a user saves receive a bounded +12 score boost. Saved-post IDs are stored under `users/{uid}/savedPosts/{postId}` and are readable only by that user. No raw watch-time tracking was introduced.


## ASRE v1.5 — Creator discovery
The recommendation engine now gives a small, bounded exploration boost to emerging creators. A trusted `onPostCreated` Cloud Function snapshots the creator's current post count and follower count onto the new post and marks creators as new when they have at most five posts or their account is at most 30 days old. These fields are written with the Firebase Admin SDK after creation; the client cannot supply them in the post-create allowlist. Missing statistics receive no discovery boost. The maximum discovery boost is 9 points. Deploy the updated Functions before expecting creator discovery metadata to appear.

## ASRE v1.6 — Gemini topic understanding
Creator Studio can optionally ask Firebase AI Logic (`gemini-3.8-flash`) for up to eight neutral topic labels based on the creator's own description and caption. The creator can preview the labels before publishing. Labels are saved to the existing `posts.topics` field and used by ASRE's existing topic matching. If AI analysis fails or is skipped, publishing remains available and the app falls back to caption tokens. No Gemini API key is stored in the app source. Enable the Gemini Developer API provider under Firebase AI Logic before testing this feature.

This package is source code, not a built APK. Run `flutter pub get`, `flutter analyze`, `flutter test`, then test Firebase AI Logic and Vimeo upload on a real test project before making a release build.


## ASRE v1.7 — Advanced Trending Feed
The feed now includes a Trending tab. Trending uses a bounded engagement-velocity score with freshness decay and creator diversity. It considers the existing `likeCount`, `commentCount`, and optional `shareCount` fields. Share counts should only be populated by trusted backend events; client-submitted counts must not be trusted. The current feed reads a bounded recent candidate set, so this is an MVP ranking layer rather than a global real-time trending index.


## ASRE v1.8 — Video metadata signals
The recommender can optionally read `durationSeconds`, `thumbnailUrl`, and `hasCaptions` from video post documents. These are optional metadata fields: missing values do not reduce ranking. The resulting boost is capped at 2 points (half-weighted in Trending). Existing upload code does not yet populate these optional fields automatically; add them only when the upload pipeline can verify the values.

## ASRE v1.9 — Creator Analytics
The Profile screen now links to a private Creator Analytics page. It reports the signed-in creator's own post count, follower count, likes, comments, and last-seven-day activity. Views, watch time, reach, and shares are intentionally not displayed because this project version does not yet collect those metrics. Run `flutter test` and `flutter analyze` before release.


## ASRE v2.0 — Explainable ranking
The ranking service now exposes `scoreBreakdown`, which reports the bounded contribution of freshness, engagement, following, positive/negative topic matches, creator discovery, saved-post preference, and accessibility metadata. `scorePost` uses the same breakdown, so its total is exactly the sum of the displayed components. This improves auditability and supports offline evaluation; it is not a trained machine-learning model. The current ranking still runs on the client over a bounded candidate set. Before public scale, move ranking to a trusted backend, add pagination and abuse controls, and evaluate relevance/fairness with consent-aware aggregate metrics.


## v2.1 Feed comments
- Connected the Home feed Comment action to a live Firestore comments sheet.
- Members can read comments in real time and submit a comment from the same sheet.
- No additional Flutter package was added. Android version build number is now +7.


## ASRE v2.2 — Comment validation
Comment input is limited to 1,000 characters in the UI and re-validated in the backend client method before writing to Firestore. Blank/whitespace-only comments are ignored. The comment sheet disposes its text controller when it closes. This is input validation, not a complete anti-spam or moderation system.


## ASRE v2.3 — Comment reporting
Users can submit a report against a specific comment. Reports include the comment and post IDs and are stored in the Firestore `reports` collection. The operator still needs a secure review workflow; this ZIP does not include an admin moderation dashboard.


## ASRE v2.4 — Secure moderator access for reports
- Firestore rules now allow report reads only for authenticated accounts carrying the trusted custom claim `moderator: true`.
- Moderators may update only `status`, `reviewedBy`, `reviewedAt`, and `moderationNote`; the report identity, reporter, target and original details remain immutable. Allowed statuses are `reviewed`, `actionTaken`, and `dismissed`.
- Assign the custom claim only from a trusted Admin SDK environment after verifying the operator. Never let a client app set its own moderator claim. Force the moderator to refresh their ID token after the claim is assigned.
- This update adds secure Firestore access for review; it does not add an in-app moderation dashboard or automatically moderate content. Test rules in the Firebase Emulator before deploying.


## ASRE v2.5 — Moderation Center
- Profile ውስጥ `moderator: true` Firebase Auth custom claim ላላቸው ተጠቃሚዎች ብቻ Moderation Center ይታያል።
- የሪፖርቶች ማንበብና ሁኔታ ማዘመን በFirestore Security Rules ይጠበቃል፤ የUI መደበቅ ብቻ የደህንነት መከላከያ አይደለም።
- Moderator የሪፖርትን `reviewed`, `actionTaken`, `dismissed` ሁኔታ እና የግምገማ ማስታወሻ ማስቀመጥ ይችላል።
- የModerator custom claim በFirebase Admin SDK በታመነ server/admin environment ብቻ ስጥ።
- `flutter pub get`, `flutter analyze`, `flutter test` እና Firebase Emulator security tests ከመልቀቅ በፊት አስኪድ።


## GitHub Cloud Build layout
Upload the contents of this project directory to the repository root. The workflow must be at `.github/workflows/android-release.yml` at the repository root.
