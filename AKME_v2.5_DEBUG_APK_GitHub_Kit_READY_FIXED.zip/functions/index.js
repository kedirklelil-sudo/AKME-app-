const { onDocumentCreated, onDocumentDeleted } = require("firebase-functions/v2/firestore");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();
const VIMEO_ACCESS_TOKEN = defineSecret("VIMEO_ACCESS_TOKEN");

// Firestore event delivery is at-least-once. Store the event ID in the same
// transaction as counter updates so retries cannot double-count engagement.
async function applyEngagementEvent(event, { postId, counterField, counterDelta, pointsDelta = 0 }) {
  const eventRef = db.collection("processedFunctionEvents").doc(event.id);
  const postRef = db.collection("posts").doc(postId);
  await db.runTransaction(async (tx) => {
    const marker = await tx.get(eventRef);
    if (marker.exists) return;
    const post = await tx.get(postRef);
    if (!post.exists) {
      tx.create(eventRef, { processedAt: new Date(), expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), outcome: "missing-post" });
      return;
    }
    const authorId = pointsDelta !== 0 ? post.get("authorId") : null;
    const userRef = authorId ? db.collection("users").doc(authorId) : null;
    const user = userRef ? await tx.get(userRef) : null;

    // All transaction reads are complete before the first write.
    const current = Number(post.get(counterField) || 0);
    tx.update(postRef, { [counterField]: Math.max(0, current + counterDelta) });
    if (user && user.exists) {
      const points = Number(user.get("points") || 0);
      tx.update(userRef, { points: Math.max(0, points + pointsDelta) });
    }
    tx.create(eventRef, { processedAt: new Date(), expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), outcome: "applied" });
  });
}

// Snapshot creator maturity on each new post. The Admin SDK writes these
// ranking hints after the client-created post passes Firestore rules, so users
// cannot award themselves an artificial discovery boost.
exports.onPostCreated = onDocumentCreated("posts/{postId}", async (event) => {
  const post = event.data;
  if (!post) return;
  const authorId = String(post.get("authorId") || "");
  if (!authorId) return;
  const authorRef = db.collection("users").doc(authorId);
  const [author, postCount, followerCount] = await Promise.all([
    authorRef.get(),
    db.collection("posts").where("authorId", "==", authorId).count().get(),
    authorRef.collection("followers").count().get(),
  ]);
  const createdAt = author.exists ? author.get("createdAt") : null;
  const accountAgeDays = createdAt && typeof createdAt.toDate === "function"
    ? Math.max(0, (Date.now() - createdAt.toDate().getTime()) / 86400000)
    : Number.POSITIVE_INFINITY;
  const totalPosts = Number(postCount.data().count || 0);
  const totalFollowers = Number(followerCount.data().count || 0);
  await post.ref.set({
    creatorPostCount: totalPosts,
    creatorFollowerCount: totalFollowers,
    creatorIsNew: totalPosts <= 5 || accountAgeDays <= 30,
    discoverySnapshotAt: new Date(),
  }, { merge: true });
});

exports.onLikeCreated = onDocumentCreated("posts/{postId}/likes/{uid}", async (event) => {
  await applyEngagementEvent(event, {
    postId: event.params.postId, counterField: "likeCount", counterDelta: 1, pointsDelta: 1,
  });
});
exports.onLikeDeleted = onDocumentDeleted("posts/{postId}/likes/{uid}", async (event) => {
  await applyEngagementEvent(event, {
    postId: event.params.postId, counterField: "likeCount", counterDelta: -1, pointsDelta: -1,
  });
});
exports.onCommentCreated = onDocumentCreated("posts/{postId}/comments/{commentId}", async (event) => {
  await applyEngagementEvent(event, {
    postId: event.params.postId, counterField: "commentCount", counterDelta: 1,
  });
});
exports.onCommentDeleted = onDocumentDeleted("posts/{postId}/comments/{commentId}", async (event) => {
  await applyEngagementEvent(event, {
    postId: event.params.postId, counterField: "commentCount", counterDelta: -1,
  });
});

exports.createVimeoUpload = onCall({ secrets: [VIMEO_ACCESS_TOKEN] }, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const sizeBytes = Number(request.data?.sizeBytes);
  const title = String(request.data?.title || "AKME video").slice(0, 120);
  const description = String(request.data?.description || "").slice(0, 1000);
  if (!Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || sizeBytes > 500 * 1024 * 1024) {
    throw new HttpsError("invalid-argument", "Video must be 1 byte to 500 MB.");
  }
  const response = await fetch("https://api.vimeo.com/me/videos", {
    method: "POST",
    headers: {
      Authorization: `bearer ${VIMEO_ACCESS_TOKEN.value()}`,
      "Content-Type": "application/json",
      Accept: "application/vnd.vimeo.*+json;version=3.4",
    },
    body: JSON.stringify({
      upload: { approach: "tus", size: String(sizeBytes) },
      name: title, description,
      privacy: { view: "unlisted", embed: "public", download: false },
    }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || !payload.upload?.upload_link || !payload.uri) {
    console.error("Vimeo ticket creation failed", response.status, payload.error || payload.developer_message);
    throw new HttpsError("failed-precondition", "Vimeo could not create an upload ticket. Check account upload access and token scopes.");
  }
  const id = String(payload.uri).split("/").filter(Boolean).pop();
  return {
    uploadLink: payload.upload.upload_link,
    videoUri: payload.uri,
    vimeoUrl: payload.link || `https://vimeo.com/${id}`,
    embedUrl: payload.player_embed_url || `https://player.vimeo.com/video/${id}`,
  };
});
