import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'screens/creator_studio_screen.dart';
import 'screens/creator_analytics_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'services/akme_backend.dart';
import 'services/akme_recommendation_engine.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const AkmeApp());
}

const ink = Color(0xFF09090D);
const panel = Color(0xFF17171F);
const accent = Color(0xFFB8A2FF);

class AkmeApp extends StatelessWidget {
  const AkmeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'AKME',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: ink,
          colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
          useMaterial3: true,
        ),
        home: const LoginScreen(),
      );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool signup = false;
  bool hidePassword = true;
  bool busy = false;
  bool acceptedLegal = false;
  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  Future<void> enter() async {
    if (signup && !acceptedLegal) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please accept the Terms and Privacy Policy to create an account.')));
      return;
    }
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter your email and password.')));
      return;
    }
    setState(() => busy = true);
    try {
      if (signup) {
        await AkmeBackend.instance.signUp(email: email.text, password: password.text, displayName: email.text.split('@').first, acceptedLegal: true);
      } else {
        await AkmeBackend.instance.signIn(email: email.text, password: password.text);
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell()));
    } on FirebaseException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? e.code)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(26), child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(child: Container(width: 86, height: 86, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)]), borderRadius: BorderRadius.circular(26)), child: const Icon(Icons.play_arrow_rounded, size: 58, color: Colors.white))),
            const SizedBox(height: 18), const Center(child: Text('AKME', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: 3))),
            const SizedBox(height: 8), Center(child: Text(signup ? 'Create your account' : 'Welcome back', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
            const SizedBox(height: 34),
            TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined), filled: true, fillColor: panel, border: OutlineInputBorder())),
            const SizedBox(height: 14),
            TextField(controller: password, obscureText: hidePassword, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), filled: true, fillColor: panel, border: const OutlineInputBorder(), suffixIcon: IconButton(onPressed: () => setState(() => hidePassword = !hidePassword), icon: Icon(hidePassword ? Icons.visibility : Icons.visibility_off)))),
            if (signup) CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: acceptedLegal,
              onChanged: busy ? null : (value) => setState(() => acceptedLegal = value ?? false),
              controlAffinity: ListTileControlAffinity.leading,
              title: Wrap(children: [
                const Text('I agree to the '),
                InkWell(child: const Text('Terms of Service', style: TextStyle(color: accent, decoration: TextDecoration.underline)), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LegalDocumentPage(title: 'Terms of Service', body: LegalDocumentsScreen.docs['Terms of Service']!)))),
                const Text(' and '),
                InkWell(child: const Text('Privacy Policy', style: TextStyle(color: accent, decoration: TextDecoration.underline)), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LegalDocumentPage(title: 'Privacy Policy', body: LegalDocumentsScreen.docs['Privacy Policy']!)))),
                const Text('.'),
              ]),
            ),
            const SizedBox(height: 22), SizedBox(height: 52, child: FilledButton(onPressed: busy ? null : enter, child: busy ? const CircularProgressIndicator() : Text(signup ? 'Create Account' : 'Sign In', style: const TextStyle(fontWeight: FontWeight.bold)))),
            TextButton(onPressed: () => setState(() { signup = !signup; acceptedLegal = false; }), child: Text(signup ? 'Already have an account? Sign in' : 'New to AKME? Create account')),
            const SizedBox(height: 12), const Text('Secure sign-in powered by Firebase.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
          ],
        )))),
      );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [FeedScreen(), LeaderboardScreen(), MessagesScreen(), ProfileScreen()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: index, children: pages),
    bottomNavigationBar: NavigationBar(
      backgroundColor: const Color(0xFF111116), indicatorColor: accent.withOpacity(.18), selectedIndex: index,
      onDestinationSelected: (value) => setState(() => index = value),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.leaderboard_outlined), selectedIcon: Icon(Icons.leaderboard), label: 'Leaderboard'),
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Message'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
      ],
    ),
  );
}


class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});
  @override
  State<FeedScreen> createState() => _FeedScreenState();
}
class _FeedScreenState extends State<FeedScreen> {
  String tab = 'For You';
  final recommendationEngine = const AkmeRecommendationEngine();
  @override
  Widget build(BuildContext context) => SafeArea(child: Column(children: [
    SizedBox(height: 58, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      _feedTab('Following'), const SizedBox(width: 20), _feedTab('For You'), const SizedBox(width: 20), _feedTab('Trending'),
    ])),
    Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: AkmeBackend.instance.feed(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return const Center(child: Text('Could not load the AKME feed.'));
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final rawPosts = snapshot.data!.docs;
        if (rawPosts.isEmpty) return const Center(child: Text('No videos yet. Open Profile → Creator Studio to publish the first video.'));
        return FutureBuilder(
          future: AkmeBackend.instance.recommendationContext(),
          builder: (context, contextSnapshot) {
            if (!contextSnapshot.hasData) return const Center(child: CircularProgressIndicator());
            final feedContext = contextSnapshot.data!;
            final posts = tab == 'Trending'
                ? recommendationEngine.rankTrending(
                    posts: rawPosts,
                    hiddenPostIds: feedContext.hiddenPostIds,
                  )
                : recommendationEngine.rank(
                    posts: rawPosts,
                    followingIds: feedContext.followingIds,
                    interestTokens: feedContext.interestTokens,
                    negativeInterestTokens: feedContext.negativeInterestTokens,
                    hiddenPostIds: feedContext.hiddenPostIds,
                    savedPostIds: feedContext.savedPostIds,
                    followingOnly: tab == 'Following',
                  );
            if (posts.isEmpty) return const Center(child: Text('No posts match this feed yet. Try For You or follow more creators.'));
            return PageView.builder(
          scrollDirection: Axis.vertical,
          itemCount: posts.length,
          itemBuilder: (context, i) {
            final post = posts[i].data();
            final embedUrl = (post['embedUrl'] ?? '').toString();
            final caption = (post['caption'] ?? '').toString();
            final author = (post['authorName'] ?? 'AKME Creator').toString();
            return Stack(fit: StackFit.expand, children: [
              if (embedUrl.isNotEmpty) VimeoEmbedPlayer(url: embedUrl)
              else const ColoredBox(color: Color(0xFF17171F)),
              Positioned(left: 18, right: 88, bottom: 28, child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('@$author', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 8),
                  Text(caption, maxLines: 4, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 8),
                  const Text('#AKME #ForYou', style: TextStyle(color: Colors.white70)),
                ],
              )),
              Positioned(right: 12, bottom: 30, child: Column(children: [
                StreamBuilder<bool>(
                  stream: AkmeBackend.instance.isLiked(posts[i].id),
                  builder: (context, liked) => IconButton(
                    iconSize: 34,
                    onPressed: () => AkmeBackend.instance.toggleLike(posts[i].id).catchError((_) {}),
                    icon: Icon(liked.data == true ? Icons.favorite : Icons.favorite_border,
                      color: liked.data == true ? Colors.pinkAccent : Colors.white),
                  ),
                ),
                const Text('Like'),
                const SizedBox(height: 8),
                StreamBuilder<bool>(
                  stream: AkmeBackend.instance.isSaved(posts[i].id),
                  builder: (context, saved) => IconButton(
                    iconSize: 30,
                    onPressed: () => AkmeBackend.instance.toggleSaved(posts[i].id).catchError((_) {}),
                    icon: Icon(saved.data == true ? Icons.bookmark : Icons.bookmark_border, color: Colors.white),
                  ),
                ),
                const Text('Save'),
                const SizedBox(height: 8),
                IconButton(iconSize: 32, onPressed: () => _showComments(context, posts[i].id), icon: const Icon(Icons.mode_comment_outlined)),
                const Text('Comment'),
                const SizedBox(height: 12),
                IconButton(iconSize: 30, onPressed: () => _notice(context, 'Use the video share link from Vimeo.'), icon: const Icon(Icons.share_outlined)),
                const Text('Share'),
                const SizedBox(height: 8),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_horiz, color: Colors.white),
                  onSelected: (value) async {
                    if (value == 'hide') {
                      await AkmeBackend.instance.markNotInterested(posts[i].id);
                      if (mounted) setState(() {});
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('We will show fewer posts like this.')));
                    }
                  },
                  itemBuilder: (_) => const [PopupMenuItem(value: 'hide', child: Text('Not interested'))],
                ),
              ])),
            ]);
          },
        );
          },
        );
      },
    )),
  ]));
  Future<void> _showComments(BuildContext pageContext, String postId) async {
    final controller = TextEditingController();
    try {
      await showModalBottomSheet<void>(
        context: pageContext,
        isScrollControlled: true,
        backgroundColor: panel,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        ),
        builder: (sheetContext) => Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 18,
            bottom: MediaQuery.of(sheetContext).viewInsets.bottom + 16,
          ),
          child: SizedBox(
            height: MediaQuery.of(sheetContext).size.height * 0.65,
            child: Column(
              children: [
                const Text('Comments', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Expanded(
                  child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: AkmeBackend.instance.comments(postId),
                    builder: (context, snapshot) {
                      if (snapshot.hasError) {
                        return const Center(child: Text('Could not load comments.'));
                      }
                      if (!snapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      final docs = snapshot.data!.docs;
                      if (docs.isEmpty) {
                        return const Center(child: Text('No comments yet. Be the first to comment.'));
                      }
                      return ListView.builder(
                        itemCount: docs.length,
                        itemBuilder: (context, index) {
                          final data = docs[index].data();
                          return ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                            title: Text((data['displayName'] ?? 'AKME Member').toString()),
                            subtitle: Text((data['text'] ?? '').toString()),
                            trailing: IconButton(
                              tooltip: 'Report comment',
                              icon: const Icon(Icons.flag_outlined, size: 20),
                              onPressed: () async {
                                final reasonController = TextEditingController();
                                try {
                                  final reason = await showDialog<String>(
                                    context: context,
                                    builder: (dialogContext) => AlertDialog(
                                      title: const Text('Report comment'),
                                      content: TextField(
                                        controller: reasonController,
                                        minLines: 2,
                                        maxLines: 4,
                                        maxLength: 1500,
                                        decoration: const InputDecoration(
                                          hintText: 'Explain why this comment should be reviewed (at least 8 characters).',
                                        ),
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () => Navigator.pop(dialogContext),
                                          child: const Text('Cancel'),
                                        ),
                                        FilledButton(
                                          onPressed: () => Navigator.pop(dialogContext, reasonController.text.trim()),
                                          child: const Text('Send report'),
                                        ),
                                      ],
                                    ),
                                  );
                                  if (reason == null) return;
                                  if (reason.length < 8) {
                                    if (context.mounted) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Please enter at least 8 characters.')),
                                      );
                                    }
                                    return;
                                  }
                                  await AkmeBackend.instance.submitReport(
                                    category: 'comment',
                                    details: reason,
                                    targetType: 'comment',
                                    targetId: docs[index].id,
                                    postId: postId,
                                  );
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Report submitted for review.')),
                                    );
                                  }
                                } catch (error) {
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text('Report not sent: $error')),
                                    );
                                  }
                                } finally {
                                  reasonController.dispose();
                                }
                              },
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: TextField(
                        controller: controller,
                        maxLength: 1000,
                        maxLines: 3,
                        minLines: 1,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) async {
                          final value = controller.text.trim();
                          if (value.isEmpty) return;
                          try {
                            await AkmeBackend.instance.addComment(postId, value);
                            controller.clear();
                          } catch (error) {
                            if (sheetContext.mounted) {
                              ScaffoldMessenger.of(sheetContext).showSnackBar(
                                SnackBar(content: Text('Comment not sent: $error')),
                              );
                            }
                          }
                        },
                        decoration: const InputDecoration(
                          hintText: 'Write a comment...',
                          border: OutlineInputBorder(),
                          isDense: true,
                          counterText: '',
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      onPressed: () async {
                        final value = controller.text.trim();
                        if (value.isEmpty) return;
                        try {
                          await AkmeBackend.instance.addComment(postId, value);
                          controller.clear();
                        } catch (error) {
                          if (sheetContext.mounted) {
                            ScaffoldMessenger.of(sheetContext).showSnackBar(
                              SnackBar(content: Text('Comment not sent: $error')),
                            );
                          }
                        }
                      },
                      icon: const Icon(Icons.send),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    } finally {
      controller.dispose();
    }
  }

  Widget _feedTab(String label) => GestureDetector(
    onTap: () => setState(() => tab = label),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(label, style: TextStyle(fontWeight: FontWeight.bold, color: tab == label ? Colors.white : Colors.white54)),
      const SizedBox(height: 6),
      Container(height: 3, width: tab == label ? 28 : 0, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(4))),
    ]),
  );
}
class VimeoEmbedPlayer extends StatefulWidget {
  const VimeoEmbedPlayer({super.key, required this.url});
  final String url;
  @override
  State<VimeoEmbedPlayer> createState() => _VimeoEmbedPlayerState();
}
class _VimeoEmbedPlayerState extends State<VimeoEmbedPlayer> {
  late final WebViewController controller;
  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF09090D))
      ..loadRequest(Uri.parse(widget.url));
  }
  @override
  Widget build(BuildContext context) => WebViewWidget(controller: controller);
}

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Leaderboard')), body: ListView(padding: const EdgeInsets.all(16), children: [const Text('Top AKME creators', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 16), for (var i = 1; i <= 5; i++) Card(color: panel, child: ListTile(leading: CircleAvatar(child: Text('$i')), title: Text('Creator $i'), trailing: Text('${6000 - i * 650} pts')))]));
}
class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Messages')), body: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.chat_bubble_outline, size: 54, color: accent), SizedBox(height: 12), Text('Your messages will appear here.'), SizedBox(height: 6), Text('Messaging backend is not connected yet.', style: TextStyle(color: Colors.white54))])));
}
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Profile'), actions: [
      IconButton(onPressed: () async { await AkmeBackend.instance.signOut(); if (context.mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false); }, icon: const Icon(Icons.logout)),
    ]),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Center(child: CircleAvatar(radius: 42, child: Icon(Icons.person, size: 46))),
      const SizedBox(height: 12),
      const Center(child: Text('AKME Member', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
      const SizedBox(height: 6),
      const Center(child: Text('Profile and account settings', style: TextStyle(color: Colors.white54))),
      const SizedBox(height: 24),
      Card(color: panel, child: ListTile(
        leading: const Icon(Icons.video_library_outlined),
        title: const Text('Creator Studio'),
        subtitle: const Text('Vimeo video upload and AI captions'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreatorStudioScreen())),
      )),
      Card(color: panel, child: ListTile(
        leading: const Icon(Icons.analytics_outlined),
        title: const Text('Creator Analytics'),
        subtitle: const Text('Your posts, followers, likes and comments'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreatorAnalyticsScreen())),
      )),
      Card(color: panel, child: ListTile(leading: const Icon(Icons.policy_outlined), title: const Text('Legal & Documents'), subtitle: const Text('Terms, privacy and community policies'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LegalDocumentsScreen())))),
      Card(color: panel, child: ListTile(leading: const Icon(Icons.delete_outline), title: const Text('Request Account Deletion'), subtitle: const Text('Send a deletion request to AKME'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountDeletionRequestScreen())))),
      Card(color: panel, child: ListTile(leading: const Icon(Icons.flag_outlined), title: const Text('Report a Problem'), subtitle: const Text('Send feedback or report an issue'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportProblemScreen())))),
      FutureBuilder<bool>(
        future: AkmeBackend.instance.currentUserIsModerator(),
        builder: (context, snapshot) {
          if (snapshot.data != true) return const SizedBox.shrink();
          return Card(color: panel, child: ListTile(
            leading: const Icon(Icons.admin_panel_settings_outlined),
            title: const Text('Moderation Center'),
            subtitle: const Text('Review user-submitted reports'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ModerationScreen())),
          ));
        },
      ),
    ]),
  );
}

class ModerationScreen extends StatelessWidget {
  const ModerationScreen({super.key});

  Future<void> _setStatus(BuildContext context, String reportId, String status) async {
    final noteController = TextEditingController();
    try {
      final note = await showDialog<String>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text('Set status: $status'),
          content: TextField(
            controller: noteController,
            minLines: 2,
            maxLines: 4,
            maxLength: 1000,
            decoration: const InputDecoration(hintText: 'Add a short moderation note'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, noteController.text.trim()), child: const Text('Save')),
          ],
        ),
      );
      if (note == null) return;
      await AkmeBackend.instance.updateReportStatus(reportId: reportId, status: status, note: note);
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Report status updated.')));
    } catch (error) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not update report: $error')));
    } finally {
      noteController.dispose();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Moderation Center')),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: AkmeBackend.instance.moderationReports(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return const Center(child: Text('Access denied or reports could not be loaded.'));
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final reports = snapshot.data!.docs;
        if (reports.isEmpty) return const Center(child: Text('No reports to review.'));
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: reports.length,
          itemBuilder: (context, index) {
            final report = reports[index];
            final data = report.data();
            final status = (data['status'] ?? 'new').toString();
            return Card(color: panel, child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${(data['category'] ?? 'Report').toString()} • $status', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text((data['details'] ?? '').toString()),
                const SizedBox(height: 6),
                Text('Target: ${(data['targetType'] ?? 'general').toString()} / ${(data['targetId'] ?? 'not specified').toString()}', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                if (status == 'new') Wrap(spacing: 8, children: [
                  TextButton(onPressed: () => _setStatus(context, report.id, 'reviewed'), child: const Text('Reviewed')),
                  TextButton(onPressed: () => _setStatus(context, report.id, 'actionTaken'), child: const Text('Action taken')),
                  TextButton(onPressed: () => _setStatus(context, report.id, 'dismissed'), child: const Text('Dismiss')),
                ]),
                if (data['moderationNote'] is String && (data['moderationNote'] as String).isNotEmpty)
                  Text('Moderator note: ${data['moderationNote']}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ]),
            ));
          },
        );
      },
    ),
  );
}

class ReportProblemScreen extends StatefulWidget {
  const ReportProblemScreen({super.key});
  @override
  State<ReportProblemScreen> createState() => _ReportProblemScreenState();
}
class _ReportProblemScreenState extends State<ReportProblemScreen> {
  final details = TextEditingController();
  String category = 'Technical problem';
  bool busy = false;
  @override
  void dispose() { details.dispose(); super.dispose(); }
  Future<void> send() async {
    if (details.text.trim().length < 8) {
      _notice(context, 'Please describe the issue in at least 8 characters.');
      return;
    }
    setState(() => busy = true);
    try {
      await AkmeBackend.instance.submitReport(category: category, details: details.text);
      if (!mounted) return;
      _notice(context, 'Thank you. Your report was sent to AKME.');
      Navigator.pop(context);
    } catch (e) {
      if (mounted) _notice(context, 'Could not send report: $e');
    } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Report a Problem')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Tell us what happened. Do not include passwords or verification codes.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Report category', border: OutlineInputBorder()), items: const [
        DropdownMenuItem(value: 'Technical problem', child: Text('Technical problem')),
        DropdownMenuItem(value: 'Abusive or harmful content', child: Text('Abusive or harmful content')),
        DropdownMenuItem(value: 'Privacy concern', child: Text('Privacy concern')),
        DropdownMenuItem(value: 'Copyright concern', child: Text('Copyright concern')),
        DropdownMenuItem(value: 'Other', child: Text('Other')),
      ], onChanged: (v) { if (v != null) setState(() => category = v); }),
      const SizedBox(height: 14),
      TextField(controller: details, minLines: 5, maxLines: 8, maxLength: 1500, decoration: const InputDecoration(labelText: 'Describe the issue', alignLabelWithHint: true, border: OutlineInputBorder())),
      const SizedBox(height: 18),
      FilledButton(onPressed: busy ? null : send, child: busy ? const CircularProgressIndicator() : const Text('Send Report')),
    ]),
  );
}

class AccountDeletionRequestScreen extends StatefulWidget {
  const AccountDeletionRequestScreen({super.key});
  @override
  State<AccountDeletionRequestScreen> createState() => _AccountDeletionRequestScreenState();
}
class _AccountDeletionRequestScreenState extends State<AccountDeletionRequestScreen> {
  final reason = TextEditingController();
  bool busy = false;
  @override
  void dispose() { reason.dispose(); super.dispose(); }
  Future<void> submit() async {
    setState(() => busy = true);
    try {
      await AkmeBackend.instance.requestAccountDeletion(reason: reason.text);
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Request submitted'),
        content: const Text('Your request has been recorded. This does not immediately delete your account. The AKME operator must verify and process it.'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ));
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) _notice(context, 'Could not submit request: $e');
    } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Request Account Deletion')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('This sends a request to AKME. Your account is not deleted automatically. The operator must verify and complete the deletion, including eligible account data and uploaded files.', style: TextStyle(color: Colors.white70, height: 1.5)),
      const SizedBox(height: 16),
      TextField(controller: reason, minLines: 2, maxLines: 4, maxLength: 500, decoration: const InputDecoration(labelText: 'Reason (optional)', border: OutlineInputBorder())),
      const SizedBox(height: 18),
      FilledButton(onPressed: busy ? null : submit, child: busy ? const CircularProgressIndicator() : const Text('Submit Deletion Request')),
    ]),
  );
}

class LegalDocumentsScreen extends StatelessWidget {
  const LegalDocumentsScreen({super.key});
  static const docs = <String, String>{
    'Terms of Service': '''AKME APP — TERMS OF SERVICE\nEffective date: November 12, 2026\n\n1. ACCEPTANCE. By accessing AKME, you agree to these Terms. If you do not agree, do not use the app.\n\n2. ABOUT AKME. AKME is intended as a social video and content-sharing platform. Available features may change as development continues.\n\n3. ACCOUNTS. Provide accurate information and keep your account credentials secure. You are responsible for activity on your account.\n\n4. USER CONTENT. You retain ownership of content you create. By uploading it, you grant AKME a non-exclusive, worldwide, royalty-free license to host, store, display and distribute it as needed to operate the service. This license is subject to deletion, legal retention and content already shared by others.\n\n5. PROHIBITED USE. Do not upload illegal, infringing, abusive, exploitative, fraudulent, threatening or harmful content, or misuse the platform.\n\n6. MODERATION. AKME may review reports and restrict or remove content or accounts that violate these Terms or applicable law. Appeals may be offered where appropriate.\n\n7. PRIVACY. Personal information is handled under the AKME Privacy Policy.\n\n8. INTELLECTUAL PROPERTY. AKME branding and original platform materials belong to their respective owners.\n\n9. SUSPENSION AND TERMINATION. Accounts may be restricted for serious or repeated violations.\n\n10. DISCLAIMER AND LIABILITY. To the extent permitted by law, the service is provided as available and without guarantees of uninterrupted operation. Liability that cannot legally be excluded is not excluded.\n\n11. CHANGES AND GOVERNING LAW. Terms may be updated. Applicable law and competent courts will be determined by the operator's actual place of establishment.\n\n12. CONTACT. Legal operator: KEDIR JAMLE KLIIL. Support and privacy requests: tradingkedir@gmail.com or akomasaneakomasanu@gmail.com.''',
    'Privacy Policy': '''AKME APP — PRIVACY POLICY\nEffective date: November 12, 2026\n\n1. INTRODUCTION. This Policy explains how AKME handles information when you use the app.\n\n2. INFORMATION. Depending on implemented features, AKME may process account details (such as name, email and username), user content (videos, images, comments and messages), and technical/diagnostic information (device, app and crash data).\n\n3. USE. Information may be used to provide accounts and app features, display content, support communications, improve reliability, prevent abuse and respond to support requests.\n\n4. SERVICE PROVIDERS. AKME's project uses Firebase packages. The operator must verify which Firebase services are enabled and disclose the actual data processed by each.\n\n5. SHARING. AKME does not sell personal information. Information may be visible when you publish content, or shared with necessary providers, when legally required, or to protect users and the service.\n\n6. SECURITY AND RETENTION. Reasonable safeguards will be used. No online service can guarantee absolute security. Information is retained only as necessary for stated purposes and legal obligations.\n\n7. YOUR RIGHTS. Depending on applicable law, you may request access, correction or deletion, or withdraw consent where relevant.\n\n8. CHILDREN. The operator must set and enforce an age limit consistent with applicable law and must not knowingly process children's data unlawfully.\n\n9. CONTACT. Legal operator: KEDIR JAMLE KLIIL. Support and privacy requests: tradingkedir@gmail.com or akomasaneakomasanu@gmail.com. The operator must publish the actual jurisdiction and data-request procedure before release.''',
    'Community Guidelines': '''AKME APP — COMMUNITY GUIDELINES\n\nAKME aims to support creativity and respectful interaction. Users must respect others, avoid harassment, bullying, threats, discrimination and unwanted contact, and respect privacy and intellectual property.\n\nDo not post illegal content, exploitative or sexually explicit content, scams, spam, harmful threats, copyright-infringing material, or another person's private information without lawful permission.\n\nDo not impersonate others, manipulate engagement or rankings, or misuse account and messaging features.\n\nUse available reporting tools when you encounter harmful content. Violations may result in content removal, feature restrictions, warnings, suspension or account termination. Appeals may be available where appropriate.''',
    'Content Moderation Policy': '''AKME APP — CONTENT MODERATION POLICY\n\nPURPOSE. This policy describes the intended handling of content reports and policy violations.\n\nREPORTING. Users should be able to report videos, comments, profiles and messages through clearly available tools. The app sends user-submitted reports to the AKME Firebase reports collection. The operator, KEDIR JAMLE KLIIL, must monitor that queue and review reports promptly; support contact: tradingkedir@gmail.com or akomasaneakomasanu@gmail.com. Automated moderation is not included.\n\nREVIEW. Reports should be reviewed with regard to context, severity, applicable law and potential harm. Human review and automated tools may be used only where actually implemented.\n\nACTIONS. Depending on the case, AKME may remove content, limit visibility, issue a warning, restrict features, suspend or terminate an account.\n\nAPPEALS. Users should be given a support channel and a way to challenge moderation decisions.\n\nCOPYRIGHT. Copyright complaints should identify the protected work and disputed content and be sent to the verified support contact.''',
    'Account Deletion Policy': '''AKME APP — ACCOUNT DELETION POLICY\n\nUsers may request deletion of their account and associated personal information through an in-app deletion feature when implemented or through the AKME support contacts: tradingkedir@gmail.com or akomasaneakomasanu@gmail.com.\n\nThe operator may verify account ownership before processing a request. Eligible profile data and user content should be deleted or anonymized within the period required by applicable law and the published deletion process.\n\nSome information may be retained where required by law or necessary for security, fraud prevention or dispute resolution. Retained information must be limited and protected.\n\nIMPORTANT: The app submits a deletion request to the AKME Firebase deletionRequests collection. This records a request; it does not automatically erase the Firebase Authentication account, posts, files or backups. The operator must securely review and complete each request, and respond through tradingkedir@gmail.com or akomasaneakomasanu@gmail.com.''',
  };
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Legal & Documents')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('AKME Legal Information', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('These documents are draft policy text. KEDIR JAMLE KLIIL must verify the app practices and add the applicable jurisdiction before public release.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 14),
      for (final entry in docs.entries) Card(color: panel, child: ListTile(title: Text(entry.key), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LegalDocumentPage(title: entry.key, body: entry.value))))),
    ]),
  );
}

class LegalDocumentPage extends StatelessWidget {
  const LegalDocumentPage({super.key, required this.title, required this.body});
  final String title;
  final String body;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: SingleChildScrollView(padding: const EdgeInsets.all(20), child: SelectableText(body, style: const TextStyle(fontSize: 14, height: 1.55))));
}

void _notice(BuildContext context, String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
