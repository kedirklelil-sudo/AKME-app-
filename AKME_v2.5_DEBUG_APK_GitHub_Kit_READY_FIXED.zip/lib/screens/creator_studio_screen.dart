import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ai_caption_service.dart';
import '../services/vimeo_service.dart';

class CreatorStudioScreen extends StatefulWidget {
  const CreatorStudioScreen({super.key});
  @override
  State<CreatorStudioScreen> createState() => _CreatorStudioScreenState();
}
class _CreatorStudioScreenState extends State<CreatorStudioScreen> {
  final _picker = ImagePicker();
  final _topic = TextEditingController();
  final _caption = TextEditingController();
  XFile? _video;
  bool _busy = false;
  double _progress = 0;
  List<String> _aiTopics = const <String>[];

  @override
  void dispose() { _topic.dispose(); _caption.dispose(); super.dispose(); }

  Future<void> _chooseVideo() async {
    final picked = await _picker.pickVideo(source: ImageSource.gallery);
    if (picked != null && mounted) setState(() => _video = picked);
  }

  Future<void> _makeCaption() async {
    if (_topic.text.trim().isEmpty) { _message('Describe your video first.'); return; }
    setState(() => _busy = true);
    try {
      _caption.text = await AiCaptionService.instance.createCaption(_topic.text.trim());
    } catch (e) {
      _message('AI caption failed. Check Firebase AI setup. $e');
    } finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _analyzeTopics() async {
    final description = _topic.text.trim();
    final caption = _caption.text.trim();
    if (description.isEmpty && caption.isEmpty) {
      _message('Add a video description or caption first.');
      return;
    }
    setState(() => _busy = true);
    try {
      final topics = await AiCaptionService.instance.extractTopics(
        description: description, caption: caption,
      );
      if (mounted) setState(() => _aiTopics = topics);
      _message(topics.isEmpty ? 'No topic labels were returned. You can still publish.' : 'Gemini found ${topics.length} topic labels.');
    } catch (e) {
      _message('Topic analysis is unavailable. You can still publish. $e');
    } finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _upload() async {
    if (_video == null) { _message('Choose a video first.'); return; }
    setState(() { _busy = true; _progress = 0; });
    try {
      await VimeoService.instance.uploadVideo(
        video: _video!, caption: _caption.text.trim(),
        aiTopics: _aiTopics,
        onProgress: (v) { if (mounted) setState(() => _progress = v); },
      );
      if (!mounted) return;
      _message('Video uploaded to Vimeo and published to the AKME feed.');
      Navigator.pop(context);
    } catch (e) { _message('Upload failed: $e'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  void _message(String value) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Creator Studio')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Publish a video', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Videos are uploaded to your connected Vimeo account. Keep Vimeo credentials on the server.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 18),
      OutlinedButton.icon(onPressed: _busy ? null : _chooseVideo, icon: const Icon(Icons.video_library_outlined),
        label: Text(_video == null ? 'Choose video from gallery' : _video!.name)),
      const SizedBox(height: 18),
      TextField(controller: _topic, minLines: 2, maxLines: 4, maxLength: 500,
        decoration: const InputDecoration(labelText: 'What is your video about?', border: OutlineInputBorder())),
      OutlinedButton.icon(onPressed: _busy ? null : _makeCaption, icon: const Icon(Icons.auto_awesome),
        label: const Text('Generate caption with Gemini AI')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: _busy ? null : _analyzeTopics, icon: const Icon(Icons.auto_awesome_outlined),
        label: const Text('Analyze topics with Gemini AI')),
      if (_aiTopics.isNotEmpty) ...[
        const SizedBox(height: 8),
        const Text('Suggested topics (used for recommendations):'),
        const SizedBox(height: 6),
        Wrap(spacing: 6, runSpacing: 6, children: _aiTopics
          .map((topic) => Chip(label: Text(topic))).toList()),
      ],
      const SizedBox(height: 14),
      TextField(controller: _caption, minLines: 2, maxLines: 5, maxLength: 1000,
        decoration: const InputDecoration(labelText: 'Video caption', border: OutlineInputBorder())),
      const SizedBox(height: 18),
      if (_busy) ...[
        LinearProgressIndicator(value: _progress > 0 ? _progress : null),
        const SizedBox(height: 8),
        Text(_progress > 0 ? 'Uploading ${(100 * _progress).toStringAsFixed(0)}%' : 'Working...'),
      ],
      FilledButton.icon(onPressed: _busy ? null : _upload, icon: const Icon(Icons.cloud_upload_outlined),
        label: const Text('Upload to Vimeo and publish')),
      const SizedBox(height: 12),
      const Text('Only upload videos you own or have permission to share. Review captions before publishing.',
        style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );
}
