import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../services/akme_backend.dart';
import '../services/creator_analytics.dart';

class CreatorAnalyticsScreen extends StatefulWidget {
  const CreatorAnalyticsScreen({super.key});

  @override
  State<CreatorAnalyticsScreen> createState() => _CreatorAnalyticsScreenState();
}

class _CreatorAnalyticsScreenState extends State<CreatorAnalyticsScreen> {
  Future<int>? _followersFuture;

  @override
  void initState() {
    super.initState();
    _refreshFollowers();
  }

  void _refreshFollowers() {
    _followersFuture = AkmeBackend.instance.myFollowerCount();
  }

  @override
  Widget build(BuildContext context) {
    final backend = AkmeBackend.instance;
    final user = backend.currentUser;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Creator Analytics')),
        body: const Center(child: Text('Sign in to view creator analytics.')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Creator Analytics'),
        actions: [
          IconButton(
            tooltip: 'Refresh follower count',
            onPressed: () => setState(_refreshFollowers),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: backend.myPosts(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text('Could not load creator analytics: ${snapshot.error}'),
            ));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;
          final postMaps = docs.map((doc) => doc.data()).toList();
          final summary = CreatorAnalyticsSummary.fromPosts(postMaps);
          final sortedDocs = [...docs]..sort((a, b) {
            final aDate = _dateOf(a.data()['createdAt']);
            final bDate = _dateOf(b.data()['createdAt']);
            return bDate.compareTo(aDate);
          });

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('Your channel overview', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('A private summary of activity on your own published posts.', style: TextStyle(color: Colors.white60)),
              const SizedBox(height: 18),
              FutureBuilder<int>(
                future: _followersFuture,
                builder: (context, followerSnapshot) => GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.8,
                  children: [
                    _MetricCard(label: 'Posts', value: '${summary.postCount}', icon: Icons.video_library_outlined),
                    _MetricCard(label: 'Followers', value: followerSnapshot.hasError ? '—' : (followerSnapshot.data?.toString() ?? '…'), icon: Icons.people_outline),
                    _MetricCard(label: 'Likes', value: '${summary.likeCount}', icon: Icons.favorite_border),
                    _MetricCard(label: 'Comments', value: '${summary.commentCount}', icon: Icons.mode_comment_outlined),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Last 7 days', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('Posts published'),
                      Text('${summary.postsLast7Days}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    ]),
                    const SizedBox(height: 8),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('Likes + comments'),
                      Text('${summary.engagementLast7Days}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    ]),
                  ]),
                ),
              ),
              const SizedBox(height: 20),
              const Text('Recent posts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (sortedDocs.isEmpty)
                const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('You have not published any posts yet.')))
              else
                ...sortedDocs.take(10).map((doc) {
                  final data = doc.data();
                  final caption = (data['caption'] ?? '').toString().trim();
                  return Card(
                    child: ListTile(
                      leading: Icon(data['mediaType'] == 'image' ? Icons.image_outlined : Icons.play_circle_outline),
                      title: Text(caption.isEmpty ? 'Untitled post' : caption, maxLines: 2, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${_safeCount(data['likeCount'])} likes  •  ${_safeCount(data['commentCount'])} comments'),
                    ),
                  );
                }),
              const SizedBox(height: 12),
              const Text(
                'Views, watch time and shares are not shown because the current app source does not yet collect verified metrics for them.',
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ],
          );
        },
      ),
    );
  }

  static int _safeCount(dynamic value) => value is num && value.isFinite && value > 0 ? value.toInt() : 0;

  static DateTime _dateOf(dynamic value) {
    if (value is DateTime) return value;
    try {
      final date = (value as dynamic).toDate();
      if (date is DateTime) return date;
    } catch (_) {}
    return DateTime.fromMillisecondsSinceEpoch(0);
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.label, required this.value, required this.icon});
  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Row(children: [
        Icon(icon, color: const Color(0xFFB8A2FF), size: 25),
        const SizedBox(width: 10),
        Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ])),
      ]),
    ),
  );
}
