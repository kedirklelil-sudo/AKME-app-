import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class VimeoService {
  VimeoService._();
  static final VimeoService instance = VimeoService._();
  final _functions = FirebaseFunctions.instanceFor(region: 'us-central1');
  final _db = FirebaseFirestore.instance;

  Future<void> uploadVideo({
    required XFile video,
    required String caption,
    List<String> aiTopics = const <String>[],
    required void Function(double progress) onProgress,
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw StateError('Sign in before uploading.');
    final file = File(video.path);
    final size = await file.length();
    if (size < 1 || size > 500 * 1024 * 1024) {
      throw StateError('Video must be between 1 byte and 500 MB.');
    }

    final callable = _functions.httpsCallable('createVimeoUpload');
    final result = await callable.call(<String, dynamic>{
      'sizeBytes': size, 'title': video.name, 'description': caption,
    });
    final data = Map<String, dynamic>.from(result.data as Map);
    final uploadLink = data['uploadLink'] as String;
    final videoUri = data['videoUri'] as String;
    final vimeoUrl = data['vimeoUrl'] as String;
    final embedUrl = data['embedUrl'] as String;

    final request = http.StreamedRequest('PATCH', Uri.parse(uploadLink))
      ..headers.addAll({
        'Tus-Resumable': '1.0.0',
        'Upload-Offset': '0',
        'Content-Type': 'application/offset+octet-stream',
        'Accept': 'application/vnd.vimeo.*+json;version=3.4',
      })
      ..contentLength = size;

    var sent = 0;
    await for (final chunk in file.openRead()) {
      request.sink.add(chunk);
      sent += chunk.length;
      onProgress(sent / size);
    }
    await request.sink.close();
    final client = http.Client();
    try {
      final response = await client.send(request);
      if (response.statusCode != 204 && response.statusCode != 200) {
        final body = await response.stream.bytesToString();
        throw HttpException('Vimeo upload returned ${response.statusCode}: $body');
      }
    } finally { client.close(); }

    final fallbackTopics = caption.toLowerCase()
        .split(RegExp(r'[^a-z0-9\u1200-\u137f]+'))
        .where((token) => token.length > 2)
        .toSet()
        .take(12)
        .toList();
    final topics = <String>{
      ...aiTopics.map((topic) => topic.trim()).where((topic) => topic.isNotEmpty && topic.length <= 48),
      ...fallbackTopics,
    }.take(12).toList();

    await _db.collection('posts').add({
      'authorId': user.uid,
      'authorName': user.displayName ?? 'AKME Creator',
      'mediaUrl': embedUrl,
      'mediaType': 'video',
      'caption': caption.trim(),
      'topics': topics,
      'vimeoUri': videoUri,
      'vimeoUrl': vimeoUrl,
      'embedUrl': embedUrl,
      'likeCount': 0,
      'commentCount': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });
    onProgress(1);
  }
}
