import 'dart:math' as math;

import 'package:cloud_firestore/cloud_firestore.dart';

/// AKME Smart Ranking Engine (ASRE) v2.0.
///
/// Ranking is intentionally explainable and bounded. scoreBreakdown exposes
/// each contribution for audits and offline evaluation. It uses recency,
/// explicit interests, follows, capped engagement and creator diversity.
/// It does not optimize for endless watch time or use sensitive attributes.
class AkmeRecommendationEngine {
  const AkmeRecommendationEngine();

  static const Set<String> _stopWords = <String>{
    'the', 'and', 'for', 'with', 'this', 'that', 'from', 'you', 'your',
    'are', 'was', 'were', 'have', 'has', 'የ', 'እና', 'ነው', 'ነበር',
  };

  /// Returns the score for one post. Kept public so scoring can be unit-tested
  /// without connecting to a live Firestore project.
  double scorePost({
    required Map<String, dynamic> data,
    required Set<String> followingIds,
    required Set<String> interestTokens,
    required Set<String> negativeInterestTokens,
    Set<String> savedPostIds = const <String>{},
    String? postId,
    DateTime? now,
  }) {
    return scoreBreakdown(
      data: data,
      followingIds: followingIds,
      interestTokens: interestTokens,
      negativeInterestTokens: negativeInterestTokens,
      savedPostIds: savedPostIds,
      postId: postId,
      now: now,
    ).values.fold<double>(0.0, (total, value) => total + value);
  }

  /// ASRE v2.0 explainability surface. Each value is an independent,
  /// bounded contribution to the final score; negative values are penalties.
  /// This makes ranking reviewable without exposing private user data.
  Map<String, double> scoreBreakdown({
    required Map<String, dynamic> data,
    required Set<String> followingIds,
    required Set<String> interestTokens,
    required Set<String> negativeInterestTokens,
    Set<String> savedPostIds = const <String>{},
    String? postId,
    DateTime? now,
  }) {
    final currentTime = now ?? DateTime.now();
    final createdAt = _readDate(data['createdAt']) ??
        currentTime.subtract(const Duration(days: 30));
    final ageHours = math.max(
      0.0,
      currentTime.difference(createdAt).inMinutes / 60.0,
    );
    final freshness = 24.0 * math.exp(-ageHours / 72.0);

    final likes = _nonNegativeInt(data['likeCount']);
    final comments = _nonNegativeInt(data['commentCount']);
    final engagement = math.min(
      18.0,
      math.log(1.0 + likes + comments * 1.7) * 4.0,
    ).toDouble();

    final authorId = (data['authorId'] ?? '').toString();
    final followBoost = followingIds.contains(authorId) ? 24.0 : 0.0;
    final postTokens = _postTokens(data);
    final positiveMatches = _normalizedTokens(interestTokens)
        .intersection(postTokens).length;
    final interestBoost = math.min(20.0, positiveMatches * 5.0).toDouble();
    final negativeMatches = _normalizedTokens(negativeInterestTokens)
        .intersection(postTokens).length;
    final negativePenalty = -math.min(18.0, negativeMatches * 6.0).toDouble();
    final creatorDiscovery = _creatorDiscoveryBoost(data);
    final savedBoost = savedPostIds.contains(
      postId ?? (data['postId'] ?? '').toString(),
    ) ? 12.0 : 0.0;
    final metadataBoost = videoMetadataCompletenessBoost(data);

    return <String, double>{
      'freshness': freshness,
      'engagement': engagement,
      'following': followBoost,
      'interestMatch': interestBoost,
      'negativeInterestPenalty': negativePenalty,
      'creatorDiscovery': creatorDiscovery,
      'savedPost': savedBoost,
      'videoAccessibilityMetadata': metadataBoost,
    };
  }

  /// Ranks the Trending tab using recent engagement velocity rather than
  /// lifetime popularity. Counts are bounded before scoring so a single
  /// extremely large counter cannot dominate the list.
  double scoreTrendingPost({
    required Map<String, dynamic> data,
    DateTime? now,
  }) {
    final currentTime = now ?? DateTime.now();
    final createdAt = _readDate(data['createdAt']);
    if (createdAt == null) return 0.0;
    final ageHours = math.max(
      0.0,
      currentTime.difference(createdAt).inMinutes / 60.0,
    );
    // Trending is intentionally short-lived: older posts gradually lose
    // momentum even when they have accumulated many lifetime likes.
    final likes = math.min(50000, _nonNegativeInt(data['likeCount']));
    final comments = math.min(10000, _nonNegativeInt(data['commentCount']));
    final shares = math.min(10000, _nonNegativeInt(data['shareCount']));
    final weightedEngagement = likes + comments * 2.5 + shares * 3.0;
    final velocity = math.log(1.0 + weightedEngagement) /
        math.pow(ageHours + 2.0, 0.55);
    final freshness = 12.0 * math.exp(-ageHours / 72.0);
    final creatorDiscovery = math.min(4.0, _creatorDiscoveryBoost(data) * 0.35);
    final videoMetadataBoost = videoMetadataCompletenessBoost(data) * 0.5;
    return math.min(100.0, velocity * 18.0 + freshness + creatorDiscovery + videoMetadataBoost)
        .toDouble();
  }

  /// Returns eligible posts in trending order, with creator diversity applied
  /// after scoring. Hidden, private, removed, and under-review posts are out.
  List<QueryDocumentSnapshot<Map<String, dynamic>>> rankTrending({
    required List<QueryDocumentSnapshot<Map<String, dynamic>>> posts,
    required Set<String> hiddenPostIds,
    DateTime? now,
  }) {
    final currentTime = now ?? DateTime.now();
    final candidates = posts.where((doc) {
      if (hiddenPostIds.contains(doc.id)) return false;
      return _isEligible(doc.data()) && _readDate(doc.data()['createdAt']) != null;
    }).toList();

    candidates.sort((a, b) {
      final byScore = scoreTrendingPost(data: b.data(), now: currentTime)
          .compareTo(scoreTrendingPost(data: a.data(), now: currentTime));
      if (byScore != 0) return byScore;
      return a.id.compareTo(b.id);
    });

    final diversified = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
    final remaining = List<QueryDocumentSnapshot<Map<String, dynamic>>>.from(candidates);
    final recentCreators = <String>[];
    while (remaining.isNotEmpty) {
      var chosenIndex = remaining.indexWhere((doc) {
        final creator = (doc.data()['authorId'] ?? '').toString();
        return recentCreators.length < 2 || !recentCreators.contains(creator);
      });
      if (chosenIndex < 0) chosenIndex = 0;
      final chosen = remaining.removeAt(chosenIndex);
      diversified.add(chosen);
      recentCreators.insert(0, (chosen.data()['authorId'] ?? '').toString());
      if (recentCreators.length > 2) recentCreators.removeLast();
    }
    return diversified;
  }

  List<QueryDocumentSnapshot<Map<String, dynamic>>> rank({
    required List<QueryDocumentSnapshot<Map<String, dynamic>>> posts,
    required Set<String> followingIds,
    required Set<String> interestTokens,
    required Set<String> hiddenPostIds,
    Set<String> negativeInterestTokens = const <String>{},
    Set<String> savedPostIds = const <String>{},
    required bool followingOnly,
    DateTime? now,
  }) {
    final currentTime = now ?? DateTime.now();
    final candidates = posts.where((doc) {
      final data = doc.data();
      final authorId = (data['authorId'] ?? '').toString();
      if (hiddenPostIds.contains(doc.id)) return false;
      if (followingOnly && !followingIds.contains(authorId)) return false;
      if (!_isEligible(data)) return false;
      return true;
    }).toList();

    double score(QueryDocumentSnapshot<Map<String, dynamic>> doc) => scorePost(
      data: doc.data(),
      followingIds: followingIds,
      interestTokens: interestTokens,
      negativeInterestTokens: negativeInterestTokens,
      savedPostIds: savedPostIds,
      postId: doc.id,
      now: currentTime,
    );

    candidates.sort((a, b) {
      final byScore = score(b).compareTo(score(a));
      if (byScore != 0) return byScore;
      final aDate = _readDate(a.data()['createdAt']);
      final bDate = _readDate(b.data()['createdAt']);
      if (aDate != null && bDate != null) {
        final byDate = bDate.compareTo(aDate);
        if (byDate != 0) return byDate;
      }
      // Stable final tie-breaker makes feed ordering reproducible.
      return a.id.compareTo(b.id);
    });

    // Avoid showing the same creator in either of the previous two positions
    // when another eligible creator is available.
    final diversified = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
    final remaining = List<QueryDocumentSnapshot<Map<String, dynamic>>>.from(candidates);
    final recentCreators = <String>[];
    while (remaining.isNotEmpty) {
      var chosenIndex = remaining.indexWhere((doc) {
        final creator = (doc.data()['authorId'] ?? '').toString();
        return recentCreators.length < 2 || !recentCreators.take(2).contains(creator);
      });
      if (chosenIndex < 0) chosenIndex = 0;
      final chosen = remaining.removeAt(chosenIndex);
      diversified.add(chosen);
      recentCreators.insert(0, (chosen.data()['authorId'] ?? '').toString());
      if (recentCreators.length > 2) recentCreators.removeLast();
    }
    return diversified;
  }

  /// Small, bounded signal for complete and accessible video metadata.
  /// It does not judge a creator's camera, resolution, popularity, or identity.
  /// Missing fields receive no penalty, preserving compatibility with older posts.
  /// Expected optional post fields: mediaType, durationSeconds, thumbnailUrl,
  /// and hasCaptions. Maximum boost is 2 points.
  double videoMetadataCompletenessBoost(Map<String, dynamic> data) {
    if ((data['mediaType'] ?? '').toString() != 'video') return 0.0;
    var score = 0.0;

    final duration = data['durationSeconds'];
    if (duration is num && duration > 0 && duration <= 600) score += 0.5;

    final thumbnail = (data['thumbnailUrl'] ?? '').toString().trim();
    if (thumbnail.startsWith('https://')) score += 0.5;

    // Captions improve accessibility; this is the strongest metadata signal.
    if (data['hasCaptions'] == true) score += 1.0;

    return math.min(2.0, score).toDouble();
  }

  /// Tokenizes Amharic and Latin text consistently for both post and profile
  /// interests. Exact token matching avoids substring errors such as
  /// matching "art" inside "party".
  Set<String> tokenize(String text) {
    final result = <String>{};
    for (final raw in text.toLowerCase().split(
      RegExp(r'[^a-z0-9\u1200-\u137f]+'),
    )) {
      final token = raw.trim();
      if (token.length > 2 && !_stopWords.contains(token)) result.add(token);
    }
    return result;
  }

  Set<String> tokensFromCaptions(Iterable<String> captions) {
    final counts = <String, int>{};
    for (final caption in captions) {
      for (final token in tokenize(caption)) {
        counts[token] = (counts[token] ?? 0) + 1;
      }
    }
    final sorted = counts.keys.toList()
      ..sort((a, b) {
        final byCount = counts[b]!.compareTo(counts[a]!);
        return byCount != 0 ? byCount : a.compareTo(b);
      });
    return sorted.take(30).toSet();
  }

  /// Gives a bounded exploration boost to emerging creators. These fields are
  /// written by the trusted post-created Cloud Function, never by the client.
  /// Missing metadata produces no boost rather than guessing.
  double _creatorDiscoveryBoost(Map<String, dynamic> data) {
    if (data['creatorIsNew'] == true) return 9.0;
    final postCount = _nonNegativeInt(data['creatorPostCount']);
    final followerCount = _nonNegativeInt(data['creatorFollowerCount']);
    if (postCount > 0 && postCount <= 5) return 7.0;
    if (followerCount > 0 && followerCount <= 100) return 5.0;
    if (followerCount > 100 && followerCount <= 1000) return 2.0;
    return 0.0;
  }

  bool _isEligible(Map<String, dynamic> data) {
    if (data['isEligibleForRecommendation'] == false) return false;
    if (data['visibility'] == 'private') return false;
    const blockedStatuses = <String>{'removed', 'blocked', 'rejected', 'underReview'};
    final status = (data['moderationStatus'] ?? '').toString();
    return !blockedStatuses.contains(status);
  }

  Set<String> _postTokens(Map<String, dynamic> data) {
    final caption = (data['caption'] ?? '').toString();
    final rawTopics = data['topics'];
    final topics = rawTopics is Iterable
        ? rawTopics.whereType<String>().join(' ')
        : (rawTopics ?? '').toString();
    return tokenize('$caption $topics');
  }

  Set<String> _normalizedTokens(Set<String> tokens) =>
      tokens.expand(tokenize).toSet();

  DateTime? _readDate(dynamic value) {
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    return null;
  }

  int _nonNegativeInt(dynamic value) =>
      value is num ? math.max(0, value.toInt()).toInt() : 0;
}
