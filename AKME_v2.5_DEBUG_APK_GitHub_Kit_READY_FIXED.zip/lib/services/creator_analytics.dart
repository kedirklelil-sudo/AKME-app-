/// Privacy-conscious creator analytics calculated from the signed-in creator's
/// own published posts. Views and shares are intentionally not estimated.
class CreatorAnalyticsSummary {
  const CreatorAnalyticsSummary({
    required this.postCount,
    required this.likeCount,
    required this.commentCount,
    required this.postsLast7Days,
    required this.engagementLast7Days,
  });

  final int postCount;
  final int likeCount;
  final int commentCount;
  final int postsLast7Days;
  final int engagementLast7Days;

  int get totalEngagement => likeCount + commentCount;

  factory CreatorAnalyticsSummary.fromPosts(
    Iterable<Map<String, dynamic>> posts, {
    DateTime? now,
  }) {
    final current = now ?? DateTime.now();
    final cutoff = current.subtract(const Duration(days: 7));
    var count = 0;
    var likes = 0;
    var comments = 0;
    var recentPosts = 0;
    var recentEngagement = 0;

    for (final post in posts) {
      count++;
      final postLikes = _safeCount(post['likeCount']);
      final postComments = _safeCount(post['commentCount']);
      likes += postLikes;
      comments += postComments;
      final createdAt = _asDateTime(post['createdAt']);
      if (createdAt != null && !createdAt.isBefore(cutoff) && !createdAt.isAfter(current)) {
        recentPosts++;
        recentEngagement += postLikes + postComments;
      }
    }

    return CreatorAnalyticsSummary(
      postCount: count,
      likeCount: likes,
      commentCount: comments,
      postsLast7Days: recentPosts,
      engagementLast7Days: recentEngagement,
    );
  }

  static int _safeCount(dynamic value) {
    if (value is! num || !value.isFinite || value < 0) return 0;
    return value.toInt();
  }

  static DateTime? _asDateTime(dynamic value) {
    if (value is DateTime) return value;
    try {
      final converted = (value as dynamic).toDate();
      if (converted is DateTime) return converted;
    } catch (_) {
      // Missing or malformed timestamps are excluded from recent metrics.
    }
    return null;
  }
}
