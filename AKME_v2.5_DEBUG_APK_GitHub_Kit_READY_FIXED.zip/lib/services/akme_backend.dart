import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';

/// Firebase backend for AKME. Call Firebase.initializeApp() before using it.
class AkmeBackend {
  AkmeBackend._();
  static final AkmeBackend instance = AkmeBackend._();

  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore db = FirebaseFirestore.instance;
  final FirebaseStorage storage = FirebaseStorage.instance;

  User? get currentUser => auth.currentUser;
  Stream<User?> authChanges() => auth.authStateChanges();

  Future<UserCredential> signUp({required String email, required String password, required String displayName, required bool acceptedLegal}) async {
    final credential = await auth.createUserWithEmailAndPassword(
      email: email.trim(), password: password,
    );
    await credential.user!.updateDisplayName(displayName.trim());
    await db.collection('users').doc(credential.user!.uid).set({
      'uid': credential.user!.uid,
      'email': email.trim(),
      'displayName': displayName.trim(),
      'photoUrl': null,
      'createdAt': FieldValue.serverTimestamp(),
      'points': 0,
      'acceptedLegal': acceptedLegal,
      'legalAcceptedAt': FieldValue.serverTimestamp(),
      'legalVersion': '2026-11-12',
    });
    return credential;
  }

  Future<UserCredential> signIn({required String email, required String password}) =>
      auth.signInWithEmailAndPassword(email: email.trim(), password: password);

  Future<void> submitReport({required String category, required String details, String? targetType, String? targetId, String? postId}) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before sending a report.');
    await db.collection('reports').add({
      'reporterUid': user.uid,
      'reporterEmail': user.email,
      'category': category,
      'details': details.trim(),
      'status': 'new',
      'createdAt': FieldValue.serverTimestamp(),
      if (targetType != null) 'targetType': targetType,
      if (targetId != null) 'targetId': targetId,
      if (postId != null) 'postId': postId,
    });
  }

  /// Returns true only when Firebase Auth supplies a trusted moderator custom claim.
  Future<bool> currentUserIsModerator() async {
    final user = currentUser;
    if (user == null) return false;
    final token = await user.getIdTokenResult(true);
    return token.claims?['moderator'] == true;
  }

  /// Moderator-only report stream; Firestore Rules enforce access on the server.
  Stream<QuerySnapshot<Map<String, dynamic>>> moderationReports() =>
      db.collection('reports').orderBy('createdAt', descending: true).limit(100).snapshots();

  /// Update only the fields permitted by backend/firestore.rules.
  Future<void> updateReportStatus({required String reportId, required String status, required String note}) async {
    if (!['reviewed', 'actionTaken', 'dismissed'].contains(status)) {
      throw ArgumentError('Unsupported moderation status.');
    }
    final user = currentUser;
    if (user == null) throw StateError('Sign in first.');
    await db.collection('reports').doc(reportId).update({
      'status': status,
      'reviewedBy': user.uid,
      'reviewedAt': FieldValue.serverTimestamp(),
      'moderationNote': note.trim(),
    });
  }

  Future<void> requestAccountDeletion({required String reason}) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before requesting account deletion.');
    await db.collection('deletionRequests').add({
      'uid': user.uid,
      'email': user.email,
      'displayName': user.displayName,
      'reason': reason.trim(),
      'status': 'pending',
      'requestedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> signOut() => auth.signOut();

  Stream<QuerySnapshot<Map<String, dynamic>>> feed({bool followingOnly = false}) {
    // Ranking is applied client-side to a bounded, recent candidate set.
    return db.collection('posts').orderBy('createdAt', descending: true).limit(100).snapshots();
  }

  /// Live posts owned by the signed-in creator, used for private analytics.
  Stream<QuerySnapshot<Map<String, dynamic>>> myPosts() {
    final uid = currentUser?.uid;
    if (uid == null) return const Stream.empty();
    return db.collection('posts').where('authorId', isEqualTo: uid).limit(100).snapshots();
  }

  /// Uses Firestore's aggregation count instead of downloading follower IDs.
  Future<int> myFollowerCount() async {
    final uid = currentUser?.uid;
    if (uid == null) return 0;
    final result = await db.collection('users').doc(uid).collection('followers').count().get();
    return result.count ?? 0;
  }

  Future<({Set<String> followingIds, Set<String> interestTokens, Set<String> negativeInterestTokens, Set<String> hiddenPostIds, Set<String> savedPostIds})> recommendationContext() async {
    final uid = currentUser?.uid;
    if (uid == null) return (followingIds: <String>{}, interestTokens: <String>{}, negativeInterestTokens: <String>{}, hiddenPostIds: <String>{}, savedPostIds: <String>{});
    final followingSnap = await db.collection('users').doc(uid).collection('following').get();
    final signalsSnap = await db.collection('users').doc(uid).collection('feedSignals').limit(250).get();
    final savedSnap = await db.collection('users').doc(uid).collection('savedPosts').limit(500).get();
    final followingIds = followingSnap.docs.map((d) => d.id).toSet();
    final interestTokens = <String>{};
    final negativeInterestTokens = <String>{};
    final hiddenPostIds = <String>{};
    final savedPostIds = savedSnap.docs.map((d) => d.id).toSet();
    for (final signal in signalsSnap.docs) {
      final data = signal.data();
      if (data['type'] == 'notInterested') {
        hiddenPostIds.add(signal.id);
        final tokens = data['tokens'];
        if (tokens is List) negativeInterestTokens.addAll(tokens.whereType<String>());
      }
      if (data['type'] == 'liked') {
        final tokens = data['tokens'];
        if (tokens is List) interestTokens.addAll(tokens.whereType<String>());
      }
    }
    return (followingIds: followingIds, interestTokens: interestTokens, negativeInterestTokens: negativeInterestTokens, hiddenPostIds: hiddenPostIds, savedPostIds: savedPostIds);
  }

  Future<void> markNotInterested(String postId) async {
    final uid = currentUser?.uid;
    if (uid == null) throw StateError('Sign in first.');
    final post = await db.collection('posts').doc(postId).get();
    final data = post.data() ?? <String, dynamic>{};
    final text = '${(data['caption'] ?? '').toString()} ${(data['topics'] ?? '').toString()}'.toLowerCase();
    final tokens = text.split(RegExp(r'[^a-z0-9\u1200-\u137f]+'))
        .where((token) => token.length > 2).take(30).toSet().toList();
    await db.collection('users').doc(uid).collection('feedSignals').doc(postId).set({
      'type': 'notInterested', 'tokens': tokens, 'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> clearNotInterested(String postId) async {
    final uid = currentUser?.uid;
    if (uid == null) return;
    final ref = db.collection('users').doc(uid).collection('feedSignals').doc(postId);
    final snap = await ref.get();
    if (snap.exists && snap.data()?['type'] == 'notInterested') await ref.delete();
  }



  Stream<bool> isSaved(String postId) {
    final uid = currentUser?.uid;
    if (uid == null) return Stream.value(false);
    return db.collection('users').doc(uid).collection('savedPosts').doc(postId)
        .snapshots().map((doc) => doc.exists);
  }

  Future<void> toggleSaved(String postId) async {
    final uid = currentUser?.uid;
    if (uid == null) throw StateError('Sign in to save posts.');
    final ref = db.collection('users').doc(uid).collection('savedPosts').doc(postId);
    final existing = await ref.get();
    if (existing.exists) {
      await ref.delete();
    } else {
      await ref.set({'postId': postId, 'savedAt': FieldValue.serverTimestamp()});
    }
  }

  Future<String> uploadPost({required XFile media, required String caption}) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before uploading.');
    final file = File(media.path);
    final ext = media.name.contains('.') ? media.name.split('.').last : 'mp4';
    final ref = storage.ref('posts/${user.uid}/${DateTime.now().microsecondsSinceEpoch}.$ext');
    final task = await ref.putFile(file);
    final url = await task.ref.getDownloadURL();
    final doc = await db.collection('posts').add({
      'authorId': user.uid,
      'authorName': user.displayName ?? 'AKME Creator',
      'mediaUrl': url,
      'mediaType': ['jpg', 'jpeg', 'png', 'webp'].contains(ext.toLowerCase()) ? 'image' : 'video',
      'caption': caption.trim(),
      'likeCount': 0,
      'commentCount': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  Stream<bool> isLiked(String postId) {
    final uid = currentUser?.uid;
    if (uid == null) return Stream.value(false);
    return db.collection('posts').doc(postId).collection('likes').doc(uid)
        .snapshots().map((doc) => doc.exists);
  }

  Future<void> toggleLike(String postId) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in to like posts.');
    final like = db.collection('posts').doc(postId).collection('likes').doc(user.uid);
    final existing = await like.get();
    final signal = db.collection('users').doc(user.uid).collection('feedSignals').doc(postId);
    if (existing.exists) {
      await like.delete();
      final signalSnap = await signal.get();
      if (signalSnap.exists && signalSnap.data()?['type'] == 'liked') await signal.delete();
    } else {
      await like.set({'uid': user.uid, 'createdAt': FieldValue.serverTimestamp()});
      final post = await db.collection('posts').doc(postId).get();
      final caption = (post.data()?['caption'] ?? '').toString().toLowerCase();
      final tokens = caption.split(RegExp(r'[^a-z0-9\u1200-\u137f]+')).where((t) => t.length > 2).take(20).toSet().toList();
      await signal.set({'type': 'liked', 'tokens': tokens, 'updatedAt': FieldValue.serverTimestamp()});
    }
    // Cloud Functions maintain likeCount and creator points securely.
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> comments(String postId) =>
      db.collection('posts').doc(postId).collection('comments')
          .orderBy('createdAt', descending: false).snapshots();

  Future<void> addComment(String postId, String text) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in to comment.');
    final value = text.trim();
    if (value.isEmpty) return;
    if (value.length > 1000) {
      throw ArgumentError('Comments must be 1,000 characters or fewer.');
    }
    await db.collection('posts').doc(postId).collection('comments').add({
      'uid': user.uid,
      'displayName': user.displayName ?? 'AKME Member',
      'text': value,
      'createdAt': FieldValue.serverTimestamp(),
    });
    // Cloud Functions maintain commentCount securely.
  }

  Future<void> follow(String creatorId) async {
    final uid = currentUser?.uid;
    if (uid == null || uid == creatorId) return;
    await db.collection('users').doc(uid).collection('following').doc(creatorId)
        .set({'createdAt': FieldValue.serverTimestamp()});
    await db.collection('users').doc(creatorId).collection('followers').doc(uid)
        .set({'createdAt': FieldValue.serverTimestamp()});
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> leaderboard() =>
      db.collection('users').orderBy('points', descending: true).limit(50).snapshots();

  Future<void> updateProfile({String? displayName, XFile? avatar}) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in first.');
    String? photoUrl;
    if (avatar != null) {
      final ref = storage.ref('avatars/${user.uid}/profile.jpg');
      await ref.putFile(File(avatar.path));
      photoUrl = await ref.getDownloadURL();
    }
    if (displayName != null && displayName.trim().isNotEmpty) {
      await user.updateDisplayName(displayName.trim());
    }
    final updates = <String, dynamic>{};
    if (displayName != null && displayName.trim().isNotEmpty) updates['displayName'] = displayName.trim();
    if (photoUrl != null) updates['photoUrl'] = photoUrl;
    if (updates.isNotEmpty) await db.collection('users').doc(user.uid).set(updates, SetOptions(merge: true));
  }
}
