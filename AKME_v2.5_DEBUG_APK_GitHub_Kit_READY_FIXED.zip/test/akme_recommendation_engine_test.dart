import 'package:flutter_test/flutter_test.dart';
import 'package:akme/services/akme_recommendation_engine.dart';

void main() {
  const engine = AkmeRecommendationEngine();
  final now = DateTime.utc(2026, 11, 17, 12);

  group('ASRE v1.5 scoring', () {
    test('matches topic tokens exactly, not as substrings', () {
      final scoreWithArt = engine.scorePost(
        data: {'caption': 'art gallery', 'createdAt': now},
        followingIds: {},
        interestTokens: {'art'},
        negativeInterestTokens: {},
        now: now,
      );
      final scoreWithParty = engine.scorePost(
        data: {'caption': 'party time', 'createdAt': now},
        followingIds: {},
        interestTokens: {'art'},
        negativeInterestTokens: {},
        now: now,
      );
      expect(scoreWithArt, greaterThan(scoreWithParty));
    });

    test('caps engagement so very large counts stay bounded', () {
      final score = engine.scorePost(
        data: {
          'caption': 'music',
          'createdAt': now,
          'likeCount': 1000000000,
          'commentCount': 1000000000,
        },
        followingIds: {},
        interestTokens: {},
        negativeInterestTokens: {},
        now: now,
      );
      expect(score, lessThanOrEqualTo(44.001));
    });

    test('applies negative-interest penalty', () {
      final baseline = engine.scorePost(
        data: {'caption': 'football highlights', 'createdAt': now},
        followingIds: {},
        interestTokens: {},
        negativeInterestTokens: {},
        now: now,
      );
      final penalized = engine.scorePost(
        data: {'caption': 'football highlights', 'createdAt': now},
        followingIds: {},
        interestTokens: {},
        negativeInterestTokens: {'football'},
        now: now,
      );
      expect(penalized, lessThan(baseline));
    });

    test('uses a conservative age for posts without a timestamp', () {
      final missingDate = engine.scorePost(
        data: {'caption': 'new post'},
        followingIds: {},
        interestTokens: {},
        negativeInterestTokens: {},
        now: now,
      );
      final freshDate = engine.scorePost(
        data: {'caption': 'new post', 'createdAt': now},
        followingIds: {},
        interestTokens: {},
        negativeInterestTokens: {},
        now: now,
      );
      expect(missingDate, lessThan(freshDate));
    });


    test('explicitly saved posts receive a bounded ranking boost', () {
      final ordinary = engine.scorePost(
        data: {'caption': 'music', 'createdAt': now},
        followingIds: {},
        interestTokens: {},
        negativeInterestTokens: {},
        postId: 'post-1',
        now: now,
      );
      final saved = engine.scorePost(
        data: {'caption': 'music', 'createdAt': now},
        followingIds: {},
        interestTokens: {},
        negativeInterestTokens: {},
        savedPostIds: {'post-1'},
        postId: 'post-1',
        now: now,
      );
      expect(saved - ordinary, 12.0);
    });

    test('gives a bounded discovery boost to emerging creators', () {
      final baseline = engine.scorePost(
        data: {'caption': 'music', 'createdAt': now},
        followingIds: {}, interestTokens: {}, negativeInterestTokens: {}, now: now,
      );
      final emerging = engine.scorePost(
        data: {
          'caption': 'music', 'createdAt': now, 'creatorIsNew': true,
          'creatorPostCount': 2, 'creatorFollowerCount': 12,
        },
        followingIds: {}, interestTokens: {}, negativeInterestTokens: {}, now: now,
      );
      expect(emerging - baseline, 9.0);
    });

    test('does not invent discovery boosts when creator stats are missing', () {
      final baseline = engine.scorePost(
        data: {'caption': 'music', 'createdAt': now},
        followingIds: {}, interestTokens: {}, negativeInterestTokens: {}, now: now,
      );
      final missingStats = engine.scorePost(
        data: {'caption': 'music', 'createdAt': now, 'creatorPostCount': 0, 'creatorFollowerCount': 0},
        followingIds: {}, interestTokens: {}, negativeInterestTokens: {}, now: now,
      );
      expect(missingStats, baseline);
    });

    test('Amharic and Latin caption tokenization is deterministic', () {
      expect(engine.tokenize('Music ሙዚቃ እና Travel'), {'music', 'ሙዚቃ', 'travel'});
      expect(engine.tokensFromCaptions(['travel music', 'music travel']),
          {'music', 'travel'});
    });
  });
  group('ASRE v1.7 trending score', () {
    test('recent engagement outranks older lifetime engagement', () {
      final recent = engine.scoreTrendingPost(
        data: {
          'createdAt': now.subtract(const Duration(hours: 1)),
          'likeCount': 35,
          'commentCount': 5,
          'shareCount': 3,
        },
        now: now,
      );
      final old = engine.scoreTrendingPost(
        data: {
          'createdAt': now.subtract(const Duration(days: 12)),
          'likeCount': 5000,
          'commentCount': 400,
          'shareCount': 200,
        },
        now: now,
      );
      expect(recent, greaterThan(old));
    });

    test('caps extreme engagement counters', () {
      final score = engine.scoreTrendingPost(
        data: {
          'createdAt': now,
          'likeCount': 999999999,
          'commentCount': 999999999,
          'shareCount': 999999999,
        },
        now: now,
      );
      expect(score, lessThanOrEqualTo(100.0));
    });

    test('missing creation timestamp receives no trending score', () {
      expect(engine.scoreTrendingPost(data: {'likeCount': 1000}, now: now), 0.0);
    });
  });


  group('ASRE v1.8 video metadata intelligence', () {
    test('rewards accessible and complete video metadata with a strict cap', () {
      final score = engine.videoMetadataCompletenessBoost({
        'mediaType': 'video',
        'durationSeconds': 42,
        'thumbnailUrl': 'https://cdn.example.test/thumb.jpg',
        'hasCaptions': true,
      });
      expect(score, 2.0);
    });

    test('does not boost image posts or videos with absent metadata', () {
      expect(engine.videoMetadataCompletenessBoost({'mediaType': 'image'}), 0.0);
      expect(engine.videoMetadataCompletenessBoost({'mediaType': 'video'}), 0.0);
    });

    test('rejects malformed duration and non-HTTPS thumbnail metadata', () {
      final score = engine.videoMetadataCompletenessBoost({
        'mediaType': 'video',
        'durationSeconds': -5,
        'thumbnailUrl': 'http://example.test/thumb.jpg',
        'hasCaptions': false,
      });
      expect(score, 0.0);
    });

    test('keeps metadata influence bounded for unreasonable values', () {
      final score = engine.videoMetadataCompletenessBoost({
        'mediaType': 'video',
        'durationSeconds': 999999,
        'thumbnailUrl': 'https://cdn.example.test/thumb.jpg',
        'hasCaptions': true,
      });
      expect(score, 1.5);
      expect(score, lessThanOrEqualTo(2.0));
    });
  });

  group('ASRE v2.0 explainability', () {
    test('score breakdown sums to the public score', () {
      final data = {
        'postId': 'post-1',
        'authorId': 'creator-1',
        'caption': 'Amharic music and art',
        'createdAt': now,
        'likeCount': 12,
        'commentCount': 3,
        'creatorIsNew': true,
        'mediaType': 'video',
        'durationSeconds': 30,
        'thumbnailUrl': 'https://example.com/thumb.jpg',
        'hasCaptions': true,
      };
      final breakdown = engine.scoreBreakdown(
        data: data,
        followingIds: {'creator-1'},
        interestTokens: {'music', 'art'},
        negativeInterestTokens: {'sports'},
        savedPostIds: {'post-1'},
        postId: 'post-1',
        now: now,
      );
      final score = engine.scorePost(
        data: data,
        followingIds: {'creator-1'},
        interestTokens: {'music', 'art'},
        negativeInterestTokens: {'sports'},
        savedPostIds: {'post-1'},
        postId: 'post-1',
        now: now,
      );
      expect(breakdown.keys, containsAll([
        'freshness', 'engagement', 'following', 'interestMatch',
        'negativeInterestPenalty', 'creatorDiscovery', 'savedPost',
        'videoAccessibilityMetadata',
      ]));
      expect(breakdown.values.fold<double>(0, (a, b) => a + b), closeTo(score, 1e-9));
      expect(breakdown['following'], 24.0);
      expect(breakdown['savedPost'], 12.0);
      expect(breakdown['negativeInterestPenalty'], lessThanOrEqualTo(0));
    });

    test('negative-interest penalty is bounded', () {
      final breakdown = engine.scoreBreakdown(
        data: {'caption': 'music art sports travel food dance', 'createdAt': now},
        followingIds: {},
        interestTokens: {},
        negativeInterestTokens: {'music', 'art', 'sports', 'travel', 'food', 'dance'},
        now: now,
      );
      expect(breakdown['negativeInterestPenalty'], -18.0);
    });
  });

}
