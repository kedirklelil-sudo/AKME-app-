import 'package:flutter_test/flutter_test.dart';
import 'package:akme/services/creator_analytics.dart';

void main() {
  group('CreatorAnalyticsSummary', () {
    final now = DateTime.utc(2026, 11, 17, 12);

    test('aggregates post, like and comment totals', () {
      final summary = CreatorAnalyticsSummary.fromPosts([
        {'likeCount': 5, 'commentCount': 2, 'createdAt': now},
        {'likeCount': 3, 'commentCount': 4, 'createdAt': now.subtract(const Duration(days: 2))},
      ], now: now);

      expect(summary.postCount, 2);
      expect(summary.likeCount, 8);
      expect(summary.commentCount, 6);
      expect(summary.totalEngagement, 14);
    });

    test('counts only posts in the last seven days in recent metrics', () {
      final summary = CreatorAnalyticsSummary.fromPosts([
        {'likeCount': 2, 'commentCount': 1, 'createdAt': now},
        {'likeCount': 100, 'commentCount': 50, 'createdAt': now.subtract(const Duration(days: 8))},
      ], now: now);

      expect(summary.postsLast7Days, 1);
      expect(summary.engagementLast7Days, 3);
    });

    test('does not count malformed or negative engagement values', () {
      final summary = CreatorAnalyticsSummary.fromPosts([
        {'likeCount': -20, 'commentCount': 'many'},
        {'likeCount': 4.9, 'commentCount': 2},
      ], now: now);

      expect(summary.postCount, 2);
      expect(summary.likeCount, 4);
      expect(summary.commentCount, 2);
      expect(summary.postsLast7Days, 0);
    });

    test('does not include future-dated posts in last-seven-day metrics', () {
      final summary = CreatorAnalyticsSummary.fromPosts([
        {'likeCount': 9, 'commentCount': 1, 'createdAt': now.add(const Duration(days: 1))},
      ], now: now);

      expect(summary.postsLast7Days, 0);
      expect(summary.engagementLast7Days, 0);
    });
  });
}
