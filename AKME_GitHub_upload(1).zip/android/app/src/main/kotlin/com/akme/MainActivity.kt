package com.akme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
