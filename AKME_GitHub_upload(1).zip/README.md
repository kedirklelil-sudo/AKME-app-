# AKME — Firebase backend starter

This package adds a Firebase backend layer to the AKME Flutter starter.

## Included
- Firebase email/password registration and sign-in wired to the login screen.
- Firestore user profiles and post records.
- Firebase Storage upload method for image/video posts.
- Firestore like/unlike transactions and comment methods.
- Follow/follower records, profile update method, and leaderboard stream.
- Firestore and Storage security rules in `backend/`.

## Important: cloud setup is still required
This ZIP contains the app-side integration and security rules. It does **not** create a Firebase project or deploy a live backend automatically. You must connect it to your own Firebase project (never share your private service-account key or passwords).

1. Create/open a Firebase project at https://console.firebase.google.com/ .
2. Add an Android app using the exact `applicationId` from `android/app/build.gradle` (create Android platform files first if absent).
3. Enable **Authentication → Email/Password**.
4. Create a **Cloud Firestore** database and enable **Storage**.
5. Install Flutter and Firebase CLI / FlutterFire CLI, then from this project folder run:

   ```bash
   flutter create --platforms=android .
   flutter pub get
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```

   Select your Firebase project and Android app. This generates `lib/firebase_options.dart` used by `main.dart`.
6. Deploy the rules in `backend/firestore.rules` and `backend/storage.rules` using Firebase Console → Firestore/Storage → Rules (or Firebase CLI).
7. Run `flutter run`. Build a release APK with `flutter build apk --release` after testing.

## Backend service API
Use `AkmeBackend.instance` from `lib/services/akme_backend.dart`:
- `signUp`, `signIn`, `signOut`, `authChanges`
- `feed`, `uploadPost`
- `toggleLike`, `isLiked`
- `comments`, `addComment`
- `follow`, `leaderboard`, `updateProfile`

## Cloud Functions and deployment

The `functions/` folder contains Node.js 20 Cloud Functions. They maintain post like/comment counters and creator points on the trusted server. The Flutter client only creates/deletes like and comment documents; it cannot write counter fields.

### Deploy to your Firebase project

1. Install Node.js 20 and Firebase CLI.
2. In this project folder run `firebase login` using your own Google account.
3. Copy `.firebaserc.example` to `.firebaserc`, then replace `YOUR_FIREBASE_PROJECT_ID` with your Firebase project ID.
4. Run `cd functions && npm install && cd ..`.
5. Run `firebase deploy --only firestore:rules,storage,functions`.
6. Check Firebase Console billing requirements. Cloud Functions deployment may require the Blaze plan; review costs and set budget alerts before enabling billing.
7. Enable Email/Password in Authentication, create Firestore and Storage, then run `flutterfire configure` to generate `lib/firebase_options.dart`.

This ZIP cannot deploy into a private Firebase account by itself. Deployment requires you to sign in and authorize Firebase CLI. Never share your password, OTP, or service-account private key.

## Current integration status
The login and sign-up screen call Firebase Authentication. The backend service methods for feed, media uploads, likes, comments, follows, leaderboard and profile are included for the next UI wiring step; the current sample feed and create sheet are still demonstration UI and do not yet call those methods. Messaging/DMs are not implemented. Do not publish this starter as a complete social network until those screens are connected, tested, and moderation/reporting controls are added.


## Security rules notes
The `backend/firestore.rules` and `backend/storage.rules` files are included and tightened for authenticated users, owner-only profile edits, post ownership, and media type/size limits. Deploy them in Firebase Console → Firestore Database → Rules and Storage → Rules. These files are not deployed to your Firebase project by downloading this ZIP.

Important: this starter currently writes like/comment documents from the app, but post counter updates are intentionally restricted to post owners. To keep counters accurate, move counter updates to a trusted Cloud Function before enabling public production use. Never make counter fields client-writable just to bypass a permission error.
