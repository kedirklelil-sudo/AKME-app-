import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'services/akme_backend.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const AkmeApp());
}

const ink = Color(0xFF09090D);
const panel = Color(0xFF17171F);
const accent = Color(0xFFB8A2FF);

class AkmeApp extends StatelessWidget {
  const AkmeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'AKME',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: ink,
          colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
          useMaterial3: true,
        ),
        home: const LoginScreen(),
      );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool signup = false;
  bool hidePassword = true;
  bool busy = false;
  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  Future<void> enter() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter your email and password.')));
      return;
    }
    setState(() => busy = true);
    try {
      if (signup) {
        await AkmeBackend.instance.signUp(email: email.text, password: password.text, displayName: email.text.split('@').first);
      } else {
        await AkmeBackend.instance.signIn(email: email.text, password: password.text);
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell()));
    } on FirebaseException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? e.code)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(26), child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(child: Container(width: 86, height: 86, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)]), borderRadius: BorderRadius.circular(26)), child: const Icon(Icons.play_arrow_rounded, size: 58, color: Colors.white))),
            const SizedBox(height: 18), const Center(child: Text('AKME', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: 3))),
            const SizedBox(height: 8), Center(child: Text(signup ? 'Create your account' : 'Welcome back', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
            const SizedBox(height: 34),
            TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined), filled: true, fillColor: panel, border: OutlineInputBorder())),
            const SizedBox(height: 14),
            TextField(controller: password, obscureText: hidePassword, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), filled: true, fillColor: panel, border: const OutlineInputBorder(), suffixIcon: IconButton(onPressed: () => setState(() => hidePassword = !hidePassword), icon: Icon(hidePassword ? Icons.visibility : Icons.visibility_off)))),
            const SizedBox(height: 22), SizedBox(height: 52, child: FilledButton(onPressed: busy ? null : enter, child: busy ? const CircularProgressIndicator() : Text(signup ? 'Create Account' : 'Sign In', style: const TextStyle(fontWeight: FontWeight.bold)))),
            TextButton(onPressed: () => setState(() => signup = !signup), child: Text(signup ? 'Already have an account? Sign in' : 'New to AKME? Create account')),
            const SizedBox(height: 12), const Text('Secure sign-in powered by Firebase.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
          ],
        )))),
      );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [FeedScreen(), LeaderboardScreen(), MessagesScreen(), ProfileScreen()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: index, children: pages),
    bottomNavigationBar: NavigationBar(
      backgroundColor: const Color(0xFF111116), indicatorColor: accent.withOpacity(.18), selectedIndex: index,
      onDestinationSelected: (value) => setState(() => index = value),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.leaderboard_outlined), selectedIcon: Icon(Icons.leaderboard), label: 'Leaderboard'),
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Message'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
      ],
    ),
  );
}

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});
  @override
  State<FeedScreen> createState() => _FeedScreenState();
}
class _FeedScreenState extends State<FeedScreen> {
  String tab = 'For You';
  final liked = <int>{};
  final captions = const ['Welcome to the AKME community.', 'Discover creators and new ideas.', 'Your next favorite video starts here.'];
  @override
  Widget build(BuildContext context) => SafeArea(child: Column(children: [
    SizedBox(height: 58, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      _feedTab('Following'), const SizedBox(width: 24), _feedTab('For You'),
    ])),
    Expanded(child: PageView.builder(scrollDirection: Axis.vertical, itemCount: captions.length, itemBuilder: (context, i) => Stack(fit: StackFit.expand, children: [
      const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF29223A), Color(0xFF101015), Color(0xFF24172E)]))),
      Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.play_circle_outline, size: 76, color: Colors.white70), const SizedBox(height: 12), Text('AKME VIDEO ${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2, color: Colors.white70))])),
      Positioned(left: 18, right: 88, bottom: 28, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('@akme_creator', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 8), Text(captions[i]), const SizedBox(height: 8), const Text('#AKME #ForYou', style: TextStyle(color: Colors.white70))])),
      Positioned(right: 12, bottom: 30, child: Column(children: [
        IconButton(iconSize: 34, onPressed: () => setState(() { liked.contains(i) ? liked.remove(i) : liked.add(i); }), icon: Icon(liked.contains(i) ? Icons.favorite : Icons.favorite_border, color: liked.contains(i) ? Colors.pinkAccent : Colors.white)), const Text('Like'), const SizedBox(height: 12),
        IconButton(iconSize: 32, onPressed: () => _notice(context, 'Comments will be connected to the backend.'), icon: const Icon(Icons.mode_comment_outlined)), const Text('Comment'), const SizedBox(height: 12),
        IconButton(iconSize: 30, onPressed: () => _notice(context, 'Video sharing will be enabled in a later version.'), icon: const Icon(Icons.share_outlined)), const Text('Share'),
      ])),
    ]))),
  ]));
  Widget _feedTab(String label) => GestureDetector(onTap: () => setState(() => tab = label), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(label, style: TextStyle(fontWeight: FontWeight.bold, color: tab == label ? Colors.white : Colors.white54)), const SizedBox(height: 6), Container(height: 3, width: tab == label ? 28 : 0, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(4)))]));
}

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Leaderboard')), body: ListView(padding: const EdgeInsets.all(16), children: [const Text('Top AKME creators', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 16), for (var i = 1; i <= 5; i++) Card(color: panel, child: ListTile(leading: CircleAvatar(child: Text('$i')), title: Text('Creator $i'), trailing: Text('${6000 - i * 650} pts')))]));
}
class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Messages')), body: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.chat_bubble_outline, size: 54, color: accent), SizedBox(height: 12), Text('Your messages will appear here.'), SizedBox(height: 6), Text('Messaging backend is not connected yet.', style: TextStyle(color: Colors.white54))])));
}
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Profile'), actions: [IconButton(onPressed: () async { await AkmeBackend.instance.signOut(); if (context.mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false); }, icon: const Icon(Icons.logout))]), body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const CircleAvatar(radius: 44, child: Icon(Icons.person, size: 48)), const SizedBox(height: 14), const Text('AKME Member', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('Edit profile and creator tools coming soon.', style: TextStyle(color: Colors.white54))])));
}
void _notice(BuildContext context, String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
