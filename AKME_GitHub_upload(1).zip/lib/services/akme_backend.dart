import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';

/// Firebase backend for AKME. Call Firebase.initializeApp() before using it.
class AkmeBackend {
  AkmeBackend._();
  static final AkmeBackend instance = AkmeBackend._();

  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore db = FirebaseFirestore.instance;
  final FirebaseStorage storage = FirebaseStorage.instance;

  User? get currentUser => auth.currentUser;
  Stream<User?> authChanges() => auth.authStateChanges();

  Future<UserCredential> signUp({required String email, required String password, required String displayName}) async {
    final credential = await auth.createUserWithEmailAndPassword(
      email: email.trim(), password: password,
    );
    await credential.user!.updateDisplayName(displayName.trim());
    await db.collection('users').doc(credential.user!.uid).set({
      'uid': credential.user!.uid,
      'email': email.trim(),
      'displayName': displayName.trim(),
      'photoUrl': null,
      'createdAt': FieldValue.serverTimestamp(),
      'points': 0,
    });
    return credential;
  }

  Future<UserCredential> signIn({required String email, required String password}) =>
      auth.signInWithEmailAndPassword(email: email.trim(), password: password);

  Future<void> signOut() => auth.signOut();

  Stream<QuerySnapshot<Map<String, dynamic>>> feed({bool followingOnly = false}) {
    // The app can filter this stream by author IDs from users/{uid}/following.
    // The default For You feed is globally ordered and paginated by Firestore.
    return db.collection('posts').orderBy('createdAt', descending: true).limit(50).snapshots();
  }

  Future<String> uploadPost({required XFile media, required String caption}) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before uploading.');
    final file = File(media.path);
    final ext = media.name.contains('.') ? media.name.split('.').last : 'mp4';
    final ref = storage.ref('posts/${user.uid}/${DateTime.now().microsecondsSinceEpoch}.$ext');
    final task = await ref.putFile(file);
    final url = await task.ref.getDownloadURL();
    final doc = await db.collection('posts').add({
      'authorId': user.uid,
      'authorName': user.displayName ?? 'AKME Creator',
      'mediaUrl': url,
      'mediaType': ['jpg', 'jpeg', 'png', 'webp'].contains(ext.toLowerCase()) ? 'image' : 'video',
      'caption': caption.trim(),
      'likeCount': 0,
      'commentCount': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  Stream<bool> isLiked(String postId) {
    final uid = currentUser?.uid;
    if (uid == null) return Stream.value(false);
    return db.collection('posts').doc(postId).collection('likes').doc(uid)
        .snapshots().map((doc) => doc.exists);
  }

  Future<void> toggleLike(String postId) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in to like posts.');
    final like = db.collection('posts').doc(postId).collection('likes').doc(user.uid);
    final existing = await like.get();
    if (existing.exists) {
      await like.delete();
    } else {
      await like.set({'uid': user.uid, 'createdAt': FieldValue.serverTimestamp()});
    }
    // Cloud Functions maintain likeCount and creator points securely.
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> comments(String postId) =>
      db.collection('posts').doc(postId).collection('comments')
          .orderBy('createdAt', descending: false).snapshots();

  Future<void> addComment(String postId, String text) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in to comment.');
    final value = text.trim();
    if (value.isEmpty) return;
    await db.collection('posts').doc(postId).collection('comments').add({
      'uid': user.uid,
      'displayName': user.displayName ?? 'AKME Member',
      'text': value,
      'createdAt': FieldValue.serverTimestamp(),
    });
    // Cloud Functions maintain commentCount securely.
  }

  Future<void> follow(String creatorId) async {
    final uid = currentUser?.uid;
    if (uid == null || uid == creatorId) return;
    await db.collection('users').doc(uid).collection('following').doc(creatorId)
        .set({'createdAt': FieldValue.serverTimestamp()});
    await db.collection('users').doc(creatorId).collection('followers').doc(uid)
        .set({'createdAt': FieldValue.serverTimestamp()});
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> leaderboard() =>
      db.collection('users').orderBy('points', descending: true).limit(50).snapshots();

  Future<void> updateProfile({String? displayName, XFile? avatar}) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in first.');
    String? photoUrl;
    if (avatar != null) {
      final ref = storage.ref('avatars/${user.uid}/profile.jpg');
      await ref.putFile(File(avatar.path));
      photoUrl = await ref.getDownloadURL();
    }
    if (displayName != null && displayName.trim().isNotEmpty) {
      await user.updateDisplayName(displayName.trim());
    }
    final updates = <String, dynamic>{};
    if (displayName != null && displayName.trim().isNotEmpty) updates['displayName'] = displayName.trim();
    if (photoUrl != null) updates['photoUrl'] = photoUrl;
    if (updates.isNotEmpty) await db.collection('users').doc(user.uid).set(updates, SetOptions(merge: true));
  }
}
