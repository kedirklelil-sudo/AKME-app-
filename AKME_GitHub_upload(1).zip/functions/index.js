const { onDocumentCreated, onDocumentDeleted } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();

// Counts and creator points are changed only by trusted server code.
async function adjustPostCounter(postId, field, amount) {
  const ref = db.collection("posts").doc(postId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) return;
    const current = Number(snap.get(field) || 0);
    tx.update(ref, { [field]: Math.max(0, current + amount) });
  });
}

async function adjustCreatorPoints(postId, amount) {
  const post = await db.collection("posts").doc(postId).get();
  if (!post.exists) return;
  const uid = post.get("authorId");
  if (!uid) return;
  const userRef = db.collection("users").doc(uid);
  await db.runTransaction(async (tx) => {
    const user = await tx.get(userRef);
    if (!user.exists) return;
    const points = Number(user.get("points") || 0);
    tx.update(userRef, { points: Math.max(0, points + amount) });
  });
}

exports.onLikeCreated = onDocumentCreated("posts/{postId}/likes/{uid}", async (event) => {
  await adjustPostCounter(event.params.postId, "likeCount", 1);
  await adjustCreatorPoints(event.params.postId, 1);
});

exports.onLikeDeleted = onDocumentDeleted("posts/{postId}/likes/{uid}", async (event) => {
  await adjustPostCounter(event.params.postId, "likeCount", -1);
  await adjustCreatorPoints(event.params.postId, -1);
});

exports.onCommentCreated = onDocumentCreated("posts/{postId}/comments/{commentId}", async (event) => {
  await adjustPostCounter(event.params.postId, "commentCount", 1);
});

exports.onCommentDeleted = onDocumentDeleted("posts/{postId}/comments/{commentId}", async (event) => {
  await adjustPostCounter(event.params.postId, "commentCount", -1);
});
